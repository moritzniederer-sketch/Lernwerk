-- ===== Lernwerk: Datenbank =====
-- In Supabase: SQL Editor → New query → alles einfügen → Run

-- Profile (eines pro Konto)
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '' check (char_length(display_name) <= 40),
  settings jsonb not null default '{}'::jsonb,
  game jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- Zusammenfassungen mit dem erstellten Lernset und dem Lernfortschritt
create table if not exists public.summaries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 140),
  source_text text not null check (char_length(source_text) between 1 and 40000),
  data jsonb,
  progress jsonb not null default '{}'::jsonb,
  progress_pc int not null default 0 check (progress_pc between 0 and 100),
  status text not null default 'wird erstellt' check (status in ('wird erstellt','fertig','fehler')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists summaries_user_idx on public.summaries(user_id, created_at desc);

-- Protokoll der KI-Aufrufe (für das Tageslimit)
create table if not exists public.generation_log (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  summary_id uuid references public.summaries(id) on delete set null,
  step text not null,
  input_tokens int,
  output_tokens int,
  created_at timestamptz not null default now()
);
create index if not exists generation_log_user_idx on public.generation_log(user_id, created_at desc);

-- Zeilenschutz: Jede Person sieht und ändert nur ihre eigenen Daten
alter table public.profiles enable row level security;
alter table public.summaries enable row level security;
alter table public.generation_log enable row level security;

drop policy if exists "profil lesen" on public.profiles;
drop policy if exists "profil ändern" on public.profiles;
create policy "profil lesen" on public.profiles for select to authenticated using (id = (select auth.uid()));
create policy "profil ändern" on public.profiles for update to authenticated using (id = (select auth.uid())) with check (id = (select auth.uid()));

drop policy if exists "eigene zusammenfassungen" on public.summaries;
create policy "eigene zusammenfassungen" on public.summaries for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

drop policy if exists "eigenes protokoll lesen" on public.generation_log;
create policy "eigenes protokoll lesen" on public.generation_log for select to authenticated using (user_id = (select auth.uid()));
-- Einträge ins Protokoll schreibt nur die Server-Funktion (mit dem service_role-Schlüssel).

-- Profil automatisch anlegen, wenn sich jemand registriert
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, left(coalesce(new.raw_user_meta_data->>'display_name', ''), 40))
  on conflict (id) do nothing;
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- updated_at automatisch setzen
create or replace function public.touch_updated_at() returns trigger language plpgsql set search_path = '' as $$
begin new.updated_at = now(); return new; end; $$;
drop trigger if exists summaries_touch on public.summaries;
create trigger summaries_touch before update on public.summaries for each row execute function public.touch_updated_at();

-- Höchstens 50 Zusammenfassungen pro Konto
create or replace function public.limit_summaries() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if (select count(*) from public.summaries where user_id = new.user_id) >= 50 then
    raise exception 'Du hast schon 50 Zusammenfassungen. Lösche zuerst eine alte.';
  end if;
  return new;
end; $$;
drop trigger if exists summaries_limit on public.summaries;
create trigger summaries_limit before insert on public.summaries for each row execute function public.limit_summaries();
