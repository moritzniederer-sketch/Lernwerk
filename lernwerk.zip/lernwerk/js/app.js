/* ===== Die Lernplattform: Konto, Übersicht, Hochladen, Einstellungen ===== */
const NAME=CFG.APP_NAME||"Lernwerk";
document.title=NAME;
let SETTINGS={pruefungen:true,proLernziel:true,spielerisch:true,dauer:40,niveau:"schule"};
let USER=null,PROFILE=null,CUR=null;   // CUR = geöffnetes Lernset {id,title,source_text}
const NIVEAUS=[["primar","Primarschule"],["schule","Oberstufe / Sek"],["gymi","Gymnasium / Berufsschule"],["erwachsene","Erwachsene / Weiterbildung"]];

/* ---------- Speichern: lokal sofort, auf dem Server leicht verzögert ---------- */
const PKEYS=["seen","tseen","ok","lz","tests","ts"];
let progTimer=null,gameTimer=null;
save=function(k,v){try{localStorage.setItem(APP.prefix+k,JSON.stringify(v))}catch(e){}
  if(CUR&&PKEYS.includes(k)){clearTimeout(progTimer);progTimer=setTimeout(syncProgress,2500)}};
function progressObj(){const o={};PKEYS.forEach(k=>o[k]=load(k,k==="tests"?[]:{}));return o}
function progressPc(){let all=0,done=0;LZ.forEach(l=>{const b=bank(l.id);b.core.concat(b.extra).forEach(t=>{all++;if(ok[ck(t)])done++})});return all?Math.round(done/all*100):0}
async function syncProgress(){if(!CUR)return;try{await API.updateSummary(CUR.id,{progress:progressObj(),progress_pc:progressPc()})}catch(e){}}
function gameSave(){try{localStorage.setItem("lp:"+(USER&&USER.id)+":game",JSON.stringify(GAME))}catch(e){}
  clearTimeout(gameTimer);gameTimer=setTimeout(()=>API.saveProfile({game:GAME}).catch(()=>{}),3000)}
window.addEventListener("pagehide",()=>{if(progTimer){clearTimeout(progTimer);syncProgress()}if(gameTimer){clearTimeout(gameTimer);API.saveProfile({game:GAME}).catch(()=>{})}});

/* ---------- Kopf- und Fusszeile ---------- */
const brand=()=>h("div",{class:"brand"},h("span",{class:"logo"},"✦"),NAME);
const footer=()=>h("footer",{class:"foot small muted"},h("a",{href:"legal/impressum.html",target:"_blank"},"Impressum")," · ",h("a",{href:"legal/datenschutz.html",target:"_blank"},"Datenschutz")," · ",h("a",{href:"legal/nutzungsbedingungen.html",target:"_blank"},"Nutzungsbedingungen"),
  API.mode==="demo"?h("p",{class:"small"},"Demo-Modus: Alles bleibt nur in diesem Browser, Aufgaben werden ohne KI erstellt."):null);
function page(...k){view(...k,footer())}
function topbar(){return h("div",{class:"topbar"},h("button",{class:"linkish",onclick:dashboard},brand()),
  h("div",{class:"row",style:"gap:6px"},h("button",{class:"ghost small",onclick:settingsPage},"⚙︎ Einstellungen"),h("button",{class:"ghost small",onclick:logout},"Abmelden")))}
const field=(label,input,hint)=>h("label",{class:"fld"},h("span",{class:"flab"},label),input,hint?h("span",{class:"small muted"},hint):null);
const errBox=()=>h("div",{class:"errbox",role:"alert"});
function showErr(box,e){box.replaceChildren(h("p",{class:"fb bad"},e&&e.message?e.message:String(e)))}
async function busy(btn,fn){const t=btn.textContent;btn.disabled=true;btn.textContent="Bitte warten …";try{return await fn()}finally{btn.disabled=false;btn.textContent=t}}

/* ---------- Start und Anmeldung ---------- */
function landing(){
  page(h("div",{class:"hero"},brand(),h("h1",null,"Aus deiner Zusammenfassung wird ",h("span",{class:"hl"},"ein Lernspiel")),
      h("p",{class:"lead"},"Lade deine Zusammenfassung hoch. "+NAME+" macht daraus Übungen zu jedem Lernziel, Probeprüfungen mit Note und – wenn du willst – Spiele mit Punkten und Rängen. Für Schülerinnen, Schüler und Erwachsene."),
      h("div",{class:"row"},h("button",{class:"primary",onclick:registerPage},"Kostenlos registrieren"),h("button",{onclick:loginPage},"Anmelden"))),
    h("div",{class:"feat"},[["📄","Hochladen","Word, PDF oder Text einfügen"],["🎯","Üben","Aufgaben zu jedem Lernziel, die sich nicht ständig wiederholen"],["📝","Probeprüfung","Mit Timer, Punkten und Note"],["🎮","Spielen","XP, Ränge, Blitzrunde, Memory und mehr"]].map(([e,t,d])=>h("div",{class:"panel"},h("div",{class:"gemo"},e),h("b",null,t),h("p",{class:"small muted"},d)))));
}
function registerPage(){
  const name=h("input",{type:"text",autocomplete:"nickname",maxlength:"40"}),mail=h("input",{type:"email",autocomplete:"email"}),pw=h("input",{type:"password",autocomplete:"new-password",minlength:"8"});
  const age=h("input",{type:"checkbox"}),agb=h("input",{type:"checkbox"});const err=errBox();
  const go=h("button",{class:"primary",type:"submit"},"Konto erstellen");
  const form=h("form",{class:"panel stack auth",onsubmit:async e=>{e.preventDefault();err.replaceChildren();
    if(!name.value.trim())return showErr(err,"Gib einen Namen ein (darf auch ein Spitzname sein).");
    if(pw.value.length<8)return showErr(err,"Das Passwort braucht mindestens 8 Zeichen.");
    if(!age.checked||!agb.checked)return showErr(err,"Bitte bestätige die beiden Kästchen.");
    try{await busy(go,async()=>{const r=await API.signUp(mail.value.trim(),pw.value,name.value.trim());
      if(r.needsConfirm)page(h("div",{class:"panel stack auth"},h("h2",null,"Fast geschafft! 📬"),h("p",null,"Wir haben dir ein Mail an ",h("b",null,mail.value.trim())," geschickt. Klicke auf den Link darin, dann kannst du dich anmelden."),h("button",{onclick:loginPage},"Zur Anmeldung")));
      else await afterLogin(true)})}catch(e){showErr(err,e)}}},
    h("h2",null,"Konto erstellen"),field("Name oder Spitzname",name,"Wird nur dir angezeigt."),field("E-Mail",mail),field("Passwort",pw,"Mindestens 8 Zeichen."),
    h("label",{class:"chk"},age,h("span",null,"Ich bin mindestens 16 Jahre alt, oder meine Eltern sind einverstanden.")),
    h("label",{class:"chk"},agb,h("span",null,"Ich akzeptiere die ",h("a",{href:"legal/nutzungsbedingungen.html",target:"_blank"},"Nutzungsbedingungen")," und habe die ",h("a",{href:"legal/datenschutz.html",target:"_blank"},"Datenschutzerklärung")," gelesen.")),
    err,go,h("p",{class:"small"},"Schon ein Konto? ",h("button",{class:"linkish",type:"button",onclick:loginPage},"Anmelden")));
  page(h("div",{class:"head"},brand(),h("button",{class:"ghost",onclick:landing},"Zurück")),form);name.focus();
}
function loginPage(){
  const mail=h("input",{type:"email",autocomplete:"email"}),pw=h("input",{type:"password",autocomplete:"current-password"});const err=errBox();const go=h("button",{class:"primary",type:"submit"},"Anmelden");
  page(h("div",{class:"head"},brand(),h("button",{class:"ghost",onclick:landing},"Zurück")),
    h("form",{class:"panel stack auth",onsubmit:async e=>{e.preventDefault();err.replaceChildren();try{await busy(go,()=>API.signIn(mail.value.trim(),pw.value));await afterLogin()}catch(x){showErr(err,x)}}},
      h("h2",null,"Willkommen zurück! 👋"),field("E-Mail",mail),field("Passwort",pw),err,go,
      h("p",{class:"small"},h("button",{class:"linkish",type:"button",onclick:forgotPage},"Passwort vergessen?")," · ",h("button",{class:"linkish",type:"button",onclick:registerPage},"Neues Konto erstellen"))));mail.focus();
}
function forgotPage(){const mail=h("input",{type:"email",autocomplete:"email"});const err=errBox();const go=h("button",{class:"primary",type:"submit"},"Link schicken");
  page(h("div",{class:"head"},brand(),h("button",{class:"ghost",onclick:loginPage},"Zurück")),
    h("form",{class:"panel stack auth",onsubmit:async e=>{e.preventDefault();try{await busy(go,()=>API.resetPassword(mail.value.trim()));err.replaceChildren(h("p",{class:"fb ok"},"Falls es ein Konto mit dieser Adresse gibt, ist jetzt ein Mail mit einem Link unterwegs."))}catch(x){showErr(err,x)}}},
      h("h2",null,"Passwort vergessen"),field("E-Mail",mail),err,go))}
function newPasswordPage(){const pw=h("input",{type:"password",autocomplete:"new-password",minlength:"8"});const err=errBox();const go=h("button",{class:"primary",type:"submit"},"Passwort speichern");
  page(brand(),h("form",{class:"panel stack auth",onsubmit:async e=>{e.preventDefault();if(pw.value.length<8)return showErr(err,"Mindestens 8 Zeichen.");try{await busy(go,()=>API.updatePassword(pw.value));history.replaceState(null,"",location.pathname);await afterLogin()}catch(x){showErr(err,x)}}},
    h("h2",null,"Neues Passwort"),field("Neues Passwort",pw),err,go))}
async function logout(){await syncProgress();CUR=null;await API.signOut();USER=null;landing()}
async function afterLogin(isNew){
  USER=await API.session();if(!USER)return landing();
  try{PROFILE=await API.getProfile()}catch(e){PROFILE={display_name:"",settings:{},game:{}}}
  SETTINGS=Object.assign({pruefungen:true,proLernziel:true,spielerisch:true,dauer:40,niveau:"schule"},PROFILE.settings||{});
  GAME=Object.assign({xp:0,best:0,wbBest:0,days:{},streak:0,last:"",bests:{}},PROFILE.game||{});
  try{const lg=JSON.parse(localStorage.getItem("lp:"+USER.id+":game"));if(lg&&lg.xp>GAME.xp){GAME=Object.assign(GAME,lg);API.saveProfile({game:GAME}).catch(()=>{})}}catch(e){}
  if(isNew||!PROFILE.settings||!Object.keys(PROFILE.settings).length)return settingsPage(true);
  dashboard();
}

/* ---------- Einstellungen ---------- */
function settingsPage(first){
  CUR=null;const s=Object.assign({},SETTINGS);
  const tog=(k,t,d)=>{const c=h("input",{type:"checkbox"});c.checked=!!s[k];c.onchange=()=>s[k]=c.checked;return h("label",{class:"toggle"},c,h("span",{class:"sw"}),h("span",null,h("b",null,t),h("span",{class:"small muted"},d)))};
  const dauer=h("select",null,[20,30,40,45,60,90].map(m=>h("option",{value:m,selected:+s.dauer===m},m+" Minuten")));dauer.onchange=()=>s.dauer=+dauer.value;
  const niv=h("select",null,NIVEAUS.map(([v,t])=>h("option",{value:v,selected:s.niveau===v},t)));niv.onchange=()=>s.niveau=niv.value;
  const name=h("input",{type:"text",value:PROFILE.display_name||"",maxlength:"40"});const err=errBox();
  const go=h("button",{class:"primary"},first?"Los geht's!":"Speichern");
  go.onclick=async()=>{try{await busy(go,()=>API.saveProfile({settings:s,display_name:name.value.trim()}));SETTINGS=s;PROFILE.settings=s;PROFILE.display_name=name.value.trim();toast("Gespeichert ✓");dashboard()}catch(e){showErr(err,e)}};
  const pw=h("input",{type:"password",autocomplete:"new-password",placeholder:"Neues Passwort (mind. 8 Zeichen)"});
  const pwb=h("button",null,"Passwort ändern");pwb.onclick=async()=>{if(pw.value.length<8)return showErr(err,"Das Passwort braucht mindestens 8 Zeichen.");try{await busy(pwb,()=>API.updatePassword(pw.value));pw.value="";toast("Passwort geändert ✓")}catch(e){showErr(err,e)}};
  const del=h("button",{class:"ghost danger"},"Konto löschen");del.onclick=()=>twoStep(del,"Konto löschen","Wirklich? Alle Zusammenfassungen werden gelöscht. Nochmals tippen",async()=>{try{await API.deleteAccount();USER=null;landing();toast("Dein Konto wurde gelöscht.")}catch(e){showErr(err,e)}});
  page(first?brand():topbar(),
    h("h1",{class:"h1s"},first?"So möchtest du lernen":"Einstellungen"),first?h("p",{class:"muted"},"Du kannst das später jederzeit ändern."):null,
    h("div",{class:"panel stack"},h("h3",null,"Was soll "+NAME+" für dich erstellen?"),
      tog("proLernziel","Aufgaben zu jedem Lernziel","Übersicht mit allen Lernzielen und passenden Übungen"),
      tog("pruefungen","Probeprüfungen","Prüfung mit Timer, Punkten und Note"),
      tog("spielerisch","Spielerisch lernen","Punkte (XP), Ränge, Serien, Konfetti und Lernspiele")),
    h("div",{class:"panel stack"},h("h3",null,"Details"),field("Dauer der Probeprüfung",dauer),field("Niveau",niv,"Danach richtet sich, wie schwierig und ausführlich die Aufgaben werden.")),
    h("div",{class:"panel stack"},h("h3",null,"Profil"),field("Name oder Spitzname",name)),
    err,h("div",{class:"row"},go,first?null:h("button",{onclick:dashboard},"Abbrechen")),
    first?null:h("div",{class:"panel stack",style:"margin-top:26px"},h("h3",null,"Konto"),h("p",{class:"small muted"},"Angemeldet als "+(USER&&USER.email)),h("div",{class:"row"},pw,pwb),h("div",{class:"row",style:"margin-top:10px"},del)));
}

/* ---------- Übersicht ---------- */
async function dashboard(){
  await syncProgress();CUR=null;G.on=false;document.onkeydown=null;
  const list=h("div",{class:"lzlist"},h("p",{class:"muted"},"Lade …"));
  const hi=(PROFILE.display_name?"Hallo "+PROFILE.display_name+"!":"Hallo!")+" 👋";
  page(topbar(),h("h1",{class:"h1s"},hi),
    SETTINGS.spielerisch?h("div",{class:"panel gamebox"},rankBar(),h("div",{class:"row",style:"margin-top:10px;gap:18px;flex-wrap:wrap"},h("span",null,"🎯 Heute: ",h("b",null,(GAME.days[today()]||0)+" / 20")," Aufgaben"),h("span",null,"🔥 ",(()=>{const n=(GAME.last===today()||GAME.last===new Date(Date.now()-864e5).toISOString().slice(0,10))?GAME.streak:0;return h("b",null,n+(n===1?" Tag":" Tage"))})()," in Folge"))):null,
    h("div",{class:"row",style:"justify-content:space-between;align-items:center;margin-top:22px"},h("h2",null,"Deine Zusammenfassungen"),h("button",{class:"primary",onclick:uploadPage},"+ Neue Zusammenfassung")),list);
  try{const l=await API.listSummaries();
    list.replaceChildren(...(l.length?l.map(s=>h("button",{class:"lzb",onclick:()=>openSummary(s.id)},h("span",{class:"lid"},"📄"),h("span",{class:"lt"},h("b",null,s.title),h("span",{class:"small muted"},s.status==="fertig"?new Date(s.created_at).toLocaleDateString("de-CH"):s.status==="fehler"?"⚠️ Fehler beim Erstellen – antippen zum Wiederholen":"⏳ wird erstellt …")),
      h("span",{class:"lp"},h("span",{class:"mini"},h("i",{style:"width:"+(s.progress_pc||0)+"%"})),h("span",{class:"small muted"},(s.progress_pc||0)+" %")))):[h("div",{class:"panel empty"},h("div",{class:"gemo"},"📚"),h("p",null,h("b",null,"Noch keine Zusammenfassung.")),h("p",{class:"small muted"},"Lade deine erste hoch – in ein bis zwei Minuten kannst du loslegen."),h("button",{class:"primary",onclick:uploadPage},"Zusammenfassung hochladen"))]))}
  catch(e){list.replaceChildren(h("p",{class:"fb bad"},e.message))}
}

/* ---------- Hochladen und Lernset erstellen ---------- */
function uploadPage(){
  const title=h("input",{type:"text",maxlength:"100",placeholder:"z. B. Geschichte: Römisches Reich"});const ta=h("textarea",{rows:"12",placeholder:"Text hier einfügen …"});
  const fi=h("input",{type:"file",accept:".docx,.pdf,.txt,.md",class:"sr",id:"upfile"});const st=h("span",{class:"small muted"},"Word (.docx), PDF oder Text");const err=errBox();
  const cnt=h("span",{class:"small muted"},"0 / "+MAX_TEXT.toLocaleString("de-CH")+" Zeichen");ta.oninput=()=>{cnt.textContent=ta.value.length.toLocaleString("de-CH")+" / "+MAX_TEXT.toLocaleString("de-CH")+" Zeichen";cnt.classList.toggle("bad",ta.value.length>MAX_TEXT)};
  fi.addEventListener("change",async()=>{const f=fi.files[0];if(!f)return;st.textContent=f.name+" wird gelesen …";err.replaceChildren();
    try{ta.value=await readOwnFile(f);ta.oninput();if(!title.value)title.value=f.name.replace(/\.[^.]+$/,"").replace(/[_-]+/g," ");st.textContent="Eingelesen: "+f.name}
    catch(e){st.textContent="Word (.docx), PDF oder Text";showErr(err,e.message==="load"?"Die Datei konnte nicht gelesen werden (keine Internetverbindung?). Kopiere den Text ins Feld.":e.message)}});
  const go=h("button",{class:"primary"},"Lernset erstellen ✨");
  go.onclick=async()=>{const text=ta.value.trim(),t=title.value.trim()||"Meine Zusammenfassung";err.replaceChildren();
    if(text.length<150)return showErr(err,"Der Text ist zu kurz. Füge mindestens ein paar Abschnitte ein.");
    if(text.length>MAX_TEXT)return showErr(err,"Der Text ist zu lang (höchstens "+MAX_TEXT.toLocaleString("de-CH")+" Zeichen). Teile ihn in zwei Zusammenfassungen auf.");
    try{const id=await busy(go,()=>API.createSummary(t,text));await buildSet(id,t,text)}catch(e){showErr(err,e)}};
  page(topbar(),h("div",{class:"head"},h("h1",{class:"h1s"},"Neue Zusammenfassung"),h("button",{class:"ghost",onclick:dashboard},"Zurück")),
    h("div",{class:"panel stack"},field("Titel",title),h("label",{class:"drop",for:"upfile"},h("strong",null,"📄 Datei auswählen"),st),fi,h("p",{class:"small muted",style:"text-align:center;margin:0"},"oder Text einfügen:"),ta,cnt,err,go),
    h("div",{class:"panel"},h("h3",null,"Tipps für gute Aufgaben"),h("ul",{class:"facts"},
      h("li",null,"Schreib die Lernziele mit in die Zusammenfassung – dann richten sich die Aufgaben genau danach."),
      h("li",null,"Überschriften und Aufzählungen helfen beim Erkennen der Themen."),
      h("li",null,"Fotos von Heftseiten gehen noch nicht – nur Text, Word oder PDF mit auswählbarem Text."),
      (API.mode==="demo"||CFG.KI===false)?h("li",null,"Ohne KI werden nur einfache Aufgaben erstellt. Am besten klappt es mit «Begriff: Erklärung»-Zeilen."):null)));
}
async function buildSet(id,title,text){
  const bar=h("span",{style:"width:3%"});const msg=h("p",null,"Los geht's …");const err=errBox();
  page(topbar(),h("div",{class:"panel stack gamebox",style:"text-align:center;margin-top:30px"},h("div",{class:"lvlemo spin"},"✨"),h("h2",null,"Dein Lernset wird erstellt"),msg,h("div",{class:"bar"},bar),h("p",{class:"small muted"},"Das dauert meistens 1–3 Minuten. Lass diese Seite offen."),err));
  try{const raw=await generateSet(id,title,text,SETTINGS,(t,p)=>{msg.textContent=t;bar.style.width=Math.round(p*100)+"%"});
    const clean=cleanSet(raw);if(clean.aufgaben.length<3)throw new ApiError("Aus diesem Text konnten kaum Aufgaben erstellt werden. Prüfe, ob es wirklich eine Zusammenfassung ist.");
    await API.updateSummary(id,{data:clean,status:"fertig",title:clean.titel||title});confetti(120);openSummary(id)}
  catch(e){await API.updateSummary(id,{status:"fehler"}).catch(()=>{});showErr(err,e);
    err.append(h("div",{class:"row",style:"justify-content:center;margin-top:10px"},h("button",{class:"primary",onclick:()=>buildSet(id,title,text)},"Nochmals versuchen"),
      API.mode!=="demo"?h("button",{onclick:async()=>{const d=cleanSet(heuristicSet(title,text));await API.updateSummary(id,{data:d,status:"fertig"});openSummary(id)}},"Einfache Aufgaben ohne KI"):null,h("button",{class:"ghost",onclick:dashboard},"Zur Übersicht")))}
}

/* ---------- Ein Lernset öffnen ---------- */
async function openSummary(id){
  let s;try{s=await API.getSummary(id)}catch(e){toast(e.message);return dashboard()}
  if(s.status!=="fertig"||!s.data)return buildSet(id,s.title,s.source_text);
  CUR={id:s.id,title:s.title,source_text:s.source_text};
  APP.prefix="lp:"+USER.id+":"+s.id+":";APP.title=s.title;
  const pr=s.progress||{};PKEYS.forEach(k=>{if(pr[k]!==undefined)try{localStorage.setItem(APP.prefix+k,JSON.stringify(pr[k]))}catch(e){}});
  seen=load("seen",{});tseen=load("tseen",{});ok=load("ok",{});lzStat=load("lz",{});tests=load("tests",[]);ts=load("ts",{});
  applyData(s.data);EXAM_MIN=+SETTINGS.dauer||40;
  if(!LZ.length){toast("In diesem Lernset sind keine Aufgaben.");return dashboard()}
  home();
}
home=function(){
  if(!CUR)return USER?dashboard():landing();
  document.onkeydown=null;G.on=false;const last=tests[tests.length-1];
  const del=h("button",{class:"ghost small danger"},"Löschen");del.onclick=()=>twoStep(del,"Löschen","Wirklich löschen? Nochmals tippen",async()=>{await API.deleteSummary(CUR.id);CUR=null;dashboard()});
  const redo=h("button",{class:"ghost small"},"Neu erstellen");redo.onclick=()=>twoStep(redo,"Neu erstellen","Fortschritt geht verloren. Nochmals tippen",async()=>{const c=CUR;CUR=null;PKEYS.forEach(k=>{try{localStorage.removeItem(APP.prefix+k)}catch(e){}});await API.updateSummary(c.id,{progress:{},progress_pc:0,status:"wird erstellt"});buildSet(c.id,c.title,c.source_text)});
  page(topbar(),h("div",{class:"head"},h("button",{class:"ghost",onclick:dashboard},"← Alle Zusammenfassungen"),null),
    h("h1",{class:"h1s"},CUR.title),
    DATA.quelle==="einfach"?h("p",{class:"note"},"Diese Aufgaben wurden ohne KI erstellt und sind deshalb einfacher."):null,
    SETTINGS.spielerisch?h("div",{class:"panel gamebox"},rankBar(),gamesGrid()):null,
    h("div",{class:"big"},
      h("button",{class:"bigb lead",onclick:mixRound},h("b",null,"Gemischte Übung"),h("span",null,"Aufgaben aus allen "+LZ.length+" Lernzielen, mit sofortiger Rückmeldung")),
      SETTINGS.pruefungen?h("button",{class:"bigb",onclick:testIntro},h("b",null,"Probeprüfung"),h("span",null,last?"Letzte Note: "+last.note.toFixed(1):EXAM_MIN+" Minuten, mit Punkten und Note")):null),
    SETTINGS.proLernziel?[h("h2",{style:"margin-top:28px"},"Nach Lernziel üben"),
      h("div",{class:"lzlist"},LZ.map(l=>{const b=bank(l.id);const all=b.core.concat(b.extra);const pc=Math.round(all.filter(t=>ok[ck(t)]).length/all.length*100);
        return h("button",{class:"lzb",onclick:()=>lzPage(l.id)},h("span",{class:"lid"},l.id),h("span",{class:"lt"},h("b",null,l.t),h("span",{class:"small muted"},l.d)),h("span",{class:"lp"},h("span",{class:"mini"},h("i",{style:"width:"+pc+"%"})),h("span",{class:"small muted"},pc+" %")))}))]:null,
    h("details",{class:"panel",style:"margin-top:24px"},h("summary",null,"Deine Zusammenfassung anzeigen"),h("pre",{class:"owntext"},CUR.source_text)),
    h("div",{class:"row",style:"margin-top:14px"},redo,del));
};
testIntro=function(){
  document.onkeydown=null;if(examTimer){clearInterval(examTimer);examTimer=null}
  page(h("div",{class:"head"},h("h2",null,"Probeprüfung"),h("button",{class:"ghost",onclick:home},"Zurück")),
    h("div",{class:"panel stack"},h("p",null,EXAM_MIN+" Minuten. Sobald du startest, läuft der Timer. Danach siehst du Note und Punkte und kannst jede Aufgabe mit Lösung durchgehen."),
      h("p",{class:"muted"},"Jede Probeprüfung wird neu zusammengestellt."+(BEGRIFFE.length>=4?" Sie beginnt mit Begriffen, dann kommen Aufgaben zu den Lernzielen und am Schluss Denkaufgaben.":"")),
      h("button",{class:"primary",onclick:()=>examStart(autoExam)},"Prüfung starten")),
    tests.length?h("div",{class:"panel"},h("h3",null,"Bisherige Prüfungen"),h("div",{class:"hist"},tests.slice(-10).reverse().map(x=>h("div",null,h("b",null,"Note "+(x.r!=null?x.r.toFixed(1):x.note.toFixed(1))),"  "+fmtP(x.p)+" / "+x.m+" Punkte, "+new Date(x.d).toLocaleDateString("de-CH"))))):null);
};

/* ---------- Start ---------- */
(async()=>{
  if(location.hash==="#neues-passwort"&&API.mode==="server"){API.onAuth(ev=>{if(ev==="PASSWORD_RECOVERY")newPasswordPage()});}
  try{const s=await API.session();if(s){if(location.hash==="#neues-passwort")return newPasswordPage();return afterLogin()}}catch(e){}
  landing();
})();
