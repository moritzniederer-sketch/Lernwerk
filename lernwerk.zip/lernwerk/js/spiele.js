/* ===== Spiel-Ebene: XP, Ränge, Serien und Lernspiele (nur wenn «spielerisch» eingeschaltet) ===== */
/* ---------- Spiel-Ebene ---------- */
const RANGS=[["Neuling",0,"🌱"],["Lernender",250,"📘"],["Entdecker",600,"🧭"],["Kenner",1100,"🔎"],["Profi",1800,"🎯"],["Experte",2700,"🧠"],["Meister",3900,"🏅"],["Grossmeister",5400,"🏆"],["Genie",7500,"💡"],["Legende",10000,"👑"]];
let GAME={xp:0,best:0,wbBest:0,days:{},streak:0,last:""};
const today=()=>new Date().toISOString().slice(0,10);
const rangOf=xp=>{let i=0;RANGS.forEach((r,k)=>{if(xp>=r[1])i=k});return i};
let G={on:false,combo:0,roundXP:0,roundOk:0,roundN:0};
const PRAISE={ok:["Richtig! 🎉","Genau so! 💪","Stark!","Perfekt! ⭐","Volltreffer! 🎯","Bravo – das sitzt!","Super gemacht! 👏","Klasse, weiter so!"],
  part:["Fast! Ein paar Punkte fehlen noch.","Halber Sieg – die Schlacht geht weiter!","Gut angefangen, schau dir die Lösung an.","Nah dran! 🔍"],
  bad:["Kein Problem – Übung macht den Meister.","Nicht schlimm! Diese Aufgabe kommt später nochmal.","Jetzt weisst du es – das zählt! 🧠","Fehler gehören zum Lernen dazu.","Weiter geht's – du schaffst das!"]};
function addXP(n){if(n<=0)return;const before=rangOf(GAME.xp);GAME.xp+=n;const d=today();
  if(GAME.last!==d){const y=new Date(Date.now()-864e5).toISOString().slice(0,10);GAME.streak=GAME.last===y?GAME.streak+1:1;GAME.last=d}
  GAME.days[d]=(GAME.days[d]||0)+1;gameSave();
  const after=rangOf(GAME.xp);if(after>before){confetti(160);setTimeout(()=>levelUp(after),350)}}
function levelUp(i){const r=RANGS[i];const ov=h("div",{class:"lvl",onclick:()=>ov.remove()},h("div",{class:"lvlbox"},h("div",{class:"lvlemo"},r[2]),h("p",{class:"small"},"Beförderung!"),h("h2",null,"Du bist jetzt "+r[0]),h("p",{class:"muted"},i<RANGS.length-1?"Nächster Rang: "+RANGS[i+1][0]+" bei "+RANGS[i+1][1]+" XP":"Höher geht es nicht. Du bist eine Legende!"),h("button",{class:"primary"},"Weiter")));document.body.append(ov);const kd=e=>{if(e.key==="Enter"||e.key==="Escape"){e.preventDefault();e.stopPropagation();close()}};const close=()=>{ov.remove();document.removeEventListener("keydown",kd,true)};ov.onclick=close;document.addEventListener("keydown",kd,true)}
function pop(txt,cls){const p=h("div",{class:"xpop "+(cls||"")},txt);document.body.append(p);setTimeout(()=>p.remove(),1500)}
function confetti(n){try{if(matchMedia("(prefers-reduced-motion: reduce)").matches)return}catch(e){}
  const c=h("canvas",{class:"confetti"});document.body.append(c);const x=c.getContext("2d");c.width=innerWidth;c.height=innerHeight;
  const col=["#9C3B2E","#D9A441","#2F7A4F","#3E6FB0","#E7C9A9"];const P=Array.from({length:n},()=>({x:innerWidth/2+(Math.random()-.5)*200,y:innerHeight*.35,vx:(Math.random()-.5)*12,vy:-Math.random()*12-4,r:Math.random()*6+4,c:R(col),a:Math.random()*6}));
  let f=0;(function step(){x.clearRect(0,0,c.width,c.height);P.forEach(p=>{p.vy+=.35;p.x+=p.vx;p.y+=p.vy;p.a+=.2;x.save();x.translate(p.x,p.y);x.rotate(p.a);x.fillStyle=p.c;x.fillRect(-p.r/2,-p.r/4,p.r,p.r/2);x.restore()});if(++f<110)requestAnimationFrame(step);else c.remove()})()}
/* Rückmeldung beim Üben aufmuntern + XP */
new MutationObserver(ms=>{if(!G.on||!SETTINGS.spielerisch)return;ms.forEach(m=>m.addedNodes.forEach(nd=>{if(!(nd instanceof HTMLElement)||!nd.classList.contains("fb"))return;
  const st=nd.querySelector("strong");const k=nd.classList.contains("ok")?"ok":nd.classList.contains("warn")?"part":"bad";
  G.roundN++;let xp;if(k==="ok"){G.combo++;G.roundOk++;xp=5+Math.min(G.combo-1,5)}else{G.combo=0;xp=k==="part"?2:1}
  if(st)st.textContent=R(PRAISE[k])+" ";G.roundXP+=xp;addXP(xp);
  pop("+"+xp+" XP"+(G.combo>=2?"  🔥 "+G.combo+"er-Serie":""),k);
  if(k==="ok"&&(G.combo===5||G.combo===10||G.combo===15)){confetti(90);toast(G.combo+" richtig in Folge – unglaublich! 🔥")}
  const b=document.getElementById("combo");if(b){b.textContent=G.combo>=2?"🔥 "+G.combo:"";b.classList.toggle("hot",G.combo>=5)}}))}).observe(document.getElementById("app"),{childList:true,subtree:true});
const _practice=practice;practice=function(title,tasks,again,pool){G.on=!!SETTINGS.spielerisch;G.combo=0;G.roundXP=0;G.roundOk=0;G.roundN=0;_practice(title,tasks,again,pool);
  const hd=app.querySelector(".head .row");if(hd)hd.prepend(h("span",{id:"combo",class:"combo"}))};
const _practiceEnd=practiceEnd;practiceEnd=function(...a){G.on=false;_practiceEnd(...a);if(!SETTINGS.spielerisch)return;const pc=G.roundN?G.roundOk/G.roundN:0;
  const msg=pc>=.9?"Grandios! Du bist bereit für die Prüfung. 🏆":pc>=.7?"Sehr stark – fast alles sitzt! 💪":pc>=.4?"Gute Arbeit! Mit jeder Runde wirst du besser.":"Dranbleiben lohnt sich – jede Runde bringt dich weiter! 🌱";
  if(pc>=.8)confetti(140);app.querySelector(".score")?.after(h("div",{class:"panel gamebox"},h("p",{class:"big1"},msg),h("p",null,"+"+G.roundXP+" XP in dieser Runde"),rankBar()))};
const _examStart=examStart;examStart=function(...a){G.on=false;return _examStart(...a)};
function rankBar(){const i=rangOf(GAME.xp),r=RANGS[i],n=RANGS[i+1];const pc=n?Math.round((GAME.xp-r[1])/(n[1]-r[1])*100):100;
  return h("div",{class:"rank"},h("span",{class:"remo"},r[2]),h("div",{style:"flex:1"},h("div",null,h("b",null,r[0]),h("span",{class:"small muted"},"  "+GAME.xp+" XP"+(n?" · noch "+(n[1]-GAME.xp)+" bis "+n[0]:""))),h("div",{class:"bar"},h("span",{style:"width:"+pc+"%"}))))}
/* ---------- Blitzrunde ---------- */
function blitzPool(){const out=[];LZ.forEach(l=>{try{const b=bank(l.id);b.core.concat(b.extra).forEach(t=>{if(t.quelle)return;if(t.type==="tf"||(t.type==="mc"&&!t.multi&&t.opts.length<=4)||(t.type==="text"&&t.q.length<170))out.push(t)})}catch(e){}});return SH(out)}
function blitz(){document.onkeydown=null;G.on=false;const pool=blitzPool();let i=0,score=0,combo=0,n=0,okN=0,left=60,over=false;
  const tm=h("b",null,"60"),sc=h("b",null,"0"),cb=h("span",{class:"combo"}),body=h("div",{class:"blitz"});
  view(h("div",{class:"head"},h("h2",null,"⚡ Blitzrunde"),h("button",{class:"ghost",onclick:()=>{over=true;clearInterval(iv);home()}},"Beenden")),h("div",{class:"row blitzbar"},h("span",null,"⏱ ",tm," s"),h("span",null,"Punkte ",sc),cb),h("div",{class:"bar"},h("span",{id:"tbar",style:"width:100%"})),body);
  const iv=setInterval(()=>{left--;tm.textContent=left;document.getElementById("tbar").style.width=(left/60*100)+"%";if(left<=0){clearInterval(iv);end()}},1000);
  function answer(t,a){if(over)return;const g=grade(t,a);n++;const good=g.s>=1;
    if(good){combo++;okN++;const p=10+Math.min(combo-1,5)*3;score+=p;pop("+"+p+(combo>=3?" 🔥"+combo:""),"ok")}else{combo=0;pop("✗ "+(g.sol||""),"bad")}
    sc.textContent=score;cb.textContent=combo>=2?"🔥 "+combo:"";body.classList.remove("flash-ok","flash-bad");void body.offsetWidth;body.classList.add(good?"flash-ok":"flash-bad");setTimeout(next,good?250:900)}
  function next(){if(over)return;const t=pool[i++%pool.length];body.replaceChildren(h("p",{class:"q"},t.q));
    if(t.type==="tf")body.append(h("div",{class:"bopts"},h("button",{class:"bopt",onclick:()=>answer(t,[0])},"✓ Stimmt"),h("button",{class:"bopt",onclick:()=>answer(t,[1])},"✗ Stimmt nicht")));
    else if(t.type==="mc")body.append(h("div",{class:"bopts col"},t.opts.map((o,k)=>h("button",{class:"bopt",onclick:()=>answer(t,[k])},o))));
    else{const inp=h("input",{type:"text",autocomplete:"off",spellcheck:"false",placeholder:"Antwort + Enter"});const go=h("button",{class:"primary",onclick:()=>answer(t,inp.value)},"OK");
      inp.onkeydown=e=>{if(e.key==="Enter"){e.preventDefault();answer(t,inp.value)}};body.append(h("div",{class:"row"},inp,go),h("button",{class:"ghost small",style:"margin-top:8px",onclick:()=>answer(t,"")},"Weiss ich nicht"));setTimeout(()=>inp.focus(),30)}}
  function end(){over=true;const rec=score>GAME.best;if(rec)GAME.best=score;gameSave();addXP(Math.round(score/8));if(rec||okN>=8)confetti(150);
    view(h("div",{class:"panel gamebox",style:"text-align:center"},h("div",{class:"lvlemo"},rec?"🏆":"⚡"),h("h2",null,rec?"Neuer Rekord!":"Zeit um!"),h("p",{class:"score"},score+" Punkte"),h("p",null,okN+" von "+n+" richtig · +"+Math.round(score/8)+" XP"),
      h("p",{class:"muted"},rec?"Du hast deinen alten Rekord geschlagen!":"Dein Rekord: "+GAME.best+". Schaffst du ihn?"),h("div",{class:"row",style:"justify-content:center;margin-top:14px"},h("button",{class:"primary",onclick:blitz},"Nochmal!"),h("button",{onclick:home},"Zur Übersicht"))))}
  next()}
/* ---------- Wer bin ich? ---------- */
function werBinIch(){document.onkeydown=null;G.on=false;const set=PICK(DATA.raetsel.map(r=>[r.loesung,r.hinweise,r.alternativen]),6);let k=0,total=0,okN=0;
  function round(){if(k>=set.length)return fin();const [name,clues,alt]=set[k];let shown=1,done=false;
    const cl=h("ol",{class:"clues"});const inp=h("input",{type:"text",autocomplete:"off",spellcheck:"false",placeholder:"Wer oder was bin ich?"});const fb=h("div");
    const more=h("button",{class:"ghost"},"Noch ein Hinweis");const go=h("button",{class:"primary"},"Raten");
    const pts=()=>[30,20,10][shown-1];const paint=()=>{cl.replaceChildren(...clues.slice(0,shown).map(c=>h("li",{class:"pop-in"},c)));more.disabled=shown>=3;go.textContent="Raten ("+pts()+" Punkte)"};
    more.onclick=()=>{shown++;paint();inp.focus()};
    const check=()=>{if(done)return;const a=inp.value.trim();if(!a){toast("Gib zuerst eine Antwort ein.");return}
      const good=[name].concat(alt||[]).some(c=>same(a,c));
      if(!good&&shown<3){shown++;paint();pop("Nicht ganz – hier ein weiterer Hinweis","bad");inp.select();return}
      done=true;inp.disabled=true;go.disabled=true;more.disabled=true;let p=0;if(good){p=pts();total+=p;okN++;addXP(Math.round(p/5));pop("+"+p,"ok");if(shown===1)confetti(70)}
      fb.replaceChildren(h("div",{class:"fb "+(good?"ok":"bad")},h("strong",null,good?(shown===1?"Wow, schon beim ersten Hinweis! 🤯 ":R(PRAISE.ok)+" "):"Schade! "),"Gesucht war: ",h("b",null,name),"."),h("button",{class:"primary",style:"margin-top:12px",onclick:()=>{k++;round()}},k<set.length-1?"Nächstes Rätsel":"Ergebnis"))};
    go.onclick=check;inp.onkeydown=e=>{if(e.key==="Enter"){e.preventDefault();done?fb.querySelector("button")?.click():check()}};
    view(h("div",{class:"head"},h("h2",null,"🕵️ Wer bin ich?"),h("button",{class:"ghost",onclick:home},"Beenden")),h("p",{class:"small muted"},"Rätsel "+(k+1)+" von "+set.length+" · "+total+" Punkte"),
      h("div",{class:"panel gamebox"},cl,h("div",{class:"row",style:"margin-top:10px"},inp),h("div",{class:"row",style:"margin-top:10px"},go,more),fb));paint();setTimeout(()=>inp.focus(),30)}
  function fin(){const rec=total>GAME.wbBest;if(rec)GAME.wbBest=total;gameSave();if(okN>=4)confetti(150);
    view(h("div",{class:"panel gamebox",style:"text-align:center"},h("div",{class:"lvlemo"},rec?"🏆":"🕵️"),h("h2",null,rec?"Neuer Rekord!":"Geschafft!"),h("p",{class:"score"},total+" Punkte"),h("p",null,okN+" von "+set.length+" Rätseln gelöst"),
      h("div",{class:"row",style:"justify-content:center;margin-top:14px"},h("button",{class:"primary",onclick:werBinIch},"Neue Rätsel"),h("button",{onclick:home},"Zur Übersicht"))))}
  round()}

/* ---------- Spieleauswahl ---------- */
function gamesGrid(){const g=(emo,t,d,fn)=>h("button",{class:"gbtn",onclick:fn},h("span",{class:"gemo"},emo),h("b",null,t),h("span",{class:"small"},d));const B=GAME.bests||{};
  return h("div",{class:"games"},
    blitzPool().length>=5?g("⚡","Blitzrunde","60 Sekunden, so viele wie möglich"+(GAME.best?" · Rekord "+GAME.best:""),blitz):null,
    DATA.raetsel.length>=3?g("🕵️","Wer bin ich?","Je weniger Hinweise, desto mehr Punkte"+(GAME.wbBest?" · Rekord "+GAME.wbBest:""),werBinIch):null,
    DATA.ereignisse.length>=4?g("⏳","Zeitreise","Was war früher? 12 Runden"+(B.zeit?" · Rekord "+B.zeit:""),zeitreise):null,
    BEGRIFFE.length>=6?g("🃏","Memory","Begriff und Erklärung finden"+(B.mem?" · Rekord "+B.mem+" Züge":""),memory):null,
    galgenWords().length>=3?g("🔤","Wort-Rätsel","Begriff Buchstabe für Buchstabe erraten"+(B.gal?" · Rekord "+B.gal:""),galgen):null)}
function setBest(k,v,lower){GAME.bests=GAME.bests||{};const o=GAME.bests[k];const rec=o==null||(lower?v<o:v>o);if(rec)GAME.bests[k]=v;gameSave();return rec}
function endScreen(emo,title,big,lines,again){view(h("div",{class:"panel gamebox",style:"text-align:center"},h("div",{class:"lvlemo"},emo),h("h2",null,title),h("p",{class:"score"},big),lines.map(l=>h("p",{class:l.c||""},l.t)),
  h("div",{class:"row",style:"justify-content:center;margin-top:14px"},h("button",{class:"primary",onclick:again},"Nochmal!"),h("button",{onclick:home},"Zur Übersicht"))))}
/* ---------- Zeitreise: Was war früher? ---------- */
const jahr=y=>y<0?(-y)+" v. Chr.":y+" n. Chr.";
function zeitreise(){document.onkeydown=null;G.on=false;let k=0,score=0,combo=0,okN=0;const N=12;
  function round(){if(k>=N)return fin();let a,b;do{[a,b]=PICK(DATA.ereignisse.map(e=>[e.jahr,e.text]),2)}while(Math.abs(a[0]-b[0])<4&&Math.random()<.7);
    const fb=h("div",{style:"min-height:60px"});const btn=e=>h("button",{class:"bopt zr",onclick:()=>pick(e)},e[1]);const bs=[btn(a),btn(b)];
    function pick(e){bs.forEach(x=>x.disabled=true);const good=e[0]===Math.min(a[0],b[0]);
      bs.forEach((x,i)=>{const ev=[a,b][i];x.classList.add(ev[0]===Math.min(a[0],b[0])?"zr-ok":"zr-bad");x.append(h("span",{class:"zrj"},jahr(ev[0])))});
      if(good){combo++;okN++;const p=10+Math.min(combo-1,4)*2;score+=p;pop("+"+p+(combo>=3?" 🔥"+combo:""),"ok")}else{combo=0;pop(R(PRAISE.bad),"bad")}
      fb.replaceChildren(h("button",{class:"primary",onclick:()=>{k++;round()}},k<N-1?"Weiter":"Ergebnis"))}
    view(h("div",{class:"head"},h("h2",null,"⏳ Zeitreise"),h("button",{class:"ghost",onclick:home},"Beenden")),h("p",{class:"small muted"},"Runde "+(k+1)+" von "+N+" · "+score+" Punkte"+(combo>=2?" · 🔥 "+combo:"")),
      h("div",{class:"panel gamebox"},h("p",{class:"q"},"Was geschah früher?"),h("div",{class:"bopts col"},bs),fb))}
  function fin(){const rec=setBest("zeit",score);addXP(Math.round(score/8));if(okN>=10)confetti(150);
    endScreen(rec?"🏆":"⏳",rec?"Neuer Rekord!":"Zeitreise beendet",score+" Punkte",[{t:okN+" von "+N+" richtig · +"+Math.round(score/8)+" XP"},{t:okN===N?"Perfekt – du bist ein wandelnder Zeitstrahl!":"Tipp: Schau dir die Jahreszahlen nochmals an.",c:"muted"}],zeitreise)}
  round()}
/* ---------- Memory ---------- */
function memory(){document.onkeydown=null;G.on=false;const src=PICK(BEGRIFFE.map(b=>[b.begriff,b.erklaerung]),6);
  const short=d=>{d=d.split(/[.:–]/)[0];return d.length>70?d.slice(0,67)+"…":d};
  const cards=SH(src.flatMap((b,i)=>[{p:i,t:b[0],k:"t"},{p:i,t:short(b[1]),k:"d"}]));let open=[],found=0,moves=0,lock=false;const t0=Date.now();
  const info=h("p",{class:"small muted"},"Züge: 0 · Paare: 0 / 6");
  const els=cards.map((c,i)=>{const e=h("button",{class:"mcard "+c.k,onclick:()=>flip(i)},h("span",{class:"mback"},"❓"),h("span",{class:"mfront"},c.t));return e});
  function flip(i){if(lock||els[i].classList.contains("up"))return;els[i].classList.add("up");open.push(i);
    if(open.length===2){moves++;const [x,y]=open;open=[];
      if(cards[x].p===cards[y].p&&cards[x].k!==cards[y].k){found++;[x,y].forEach(j=>els[j].classList.add("done"));pop("Paar gefunden!","ok");if(found===6)setTimeout(fin,600)}
      else{lock=true;setTimeout(()=>{[x,y].forEach(j=>els[j].classList.remove("up"));lock=false},1100)}
      info.textContent="Züge: "+moves+" · Paare: "+found+" / 6"}}
  function fin(){const rec=setBest("mem",moves,true);const xp=Math.max(5,40-moves*2);addXP(xp);confetti(rec?150:80);
    endScreen(rec?"🏆":"🃏",rec?"Neuer Rekord!":"Alle Paare gefunden!",moves+" Züge",[{t:Math.round((Date.now()-t0)/1000)+" Sekunden · +"+xp+" XP"},{t:"Je weniger Züge, desto mehr XP.",c:"muted"}],memory)}
  view(h("div",{class:"head"},h("h2",null,"🃏 Memory"),h("button",{class:"ghost",onclick:home},"Beenden")),h("p",{class:"small"},"Finde zu jedem Begriff die passende Erklärung."),info,h("div",{class:"mgrid"},els))}
/* ---------- Wort-Rätsel (Galgenmännchen) ---------- */
function galgenWords(){const L=BEGRIFFE.map(b=>[b.begriff.replace(/\s*\(.*\)/,""),b.erklaerung]);
  return L.filter(w=>/^[A-Za-zÄÖÜäöüß .-]+$/.test(w[0])&&w[0].length>=4&&w[0].length<=20)}
function galgen(){document.onkeydown=null;G.on=false;const W=PICK(galgenWords(),5);let k=0,score=0,solved=0;
  function round(){if(k>=W.length)return fin();const [word,hint]=W[k];const up=word.toUpperCase();const got=new Set([" ","-","."]);let lives=7,done=false;
    const disp=h("div",{class:"gword"}),hearts=h("div",{class:"hearts"}),fb=h("div");const keys={};
    const letters="ABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÜ".split("");
    const kb=h("div",{class:"kb"},letters.map(L=>keys[L]=h("button",{class:"key",onclick:()=>guess(L)},L)));
    const paint=()=>{disp.replaceChildren(...[...up].map(c=>h("span",{class:"gl"+(c===" "?" sp":"")},got.has(c)?c:"")));hearts.textContent="🛡️".repeat(lives)+"▫️".repeat(7-lives)};
    function guess(L){if(done||got.has(L))return;got.add(L);keys[L].disabled=true;
      if(up.includes(L)){keys[L].classList.add("kok")}else{keys[L].classList.add("kbad");lives--}
      paint();const win=[...up].every(c=>got.has(c));
      if(win||lives<=0){done=true;Object.values(keys).forEach(b=>b.disabled=true);
        if(win){const p=10+lives*3;score+=p;solved++;pop("+"+p,"ok");if(lives>=6)confetti(70)}else{[...up].forEach(c=>got.add(c));paint()}
        fb.replaceChildren(h("div",{class:"fb "+(win?"ok":"bad")},h("strong",null,win?R(PRAISE.ok)+" ":"Leider verloren … "),"Lösung: ",h("b",null,word)),h("button",{class:"primary",style:"margin-top:10px",onclick:()=>{document.onkeydown=null;k++;round()}},k<W.length-1?"Nächstes Wort":"Ergebnis"))}}
    document.onkeydown=e=>{const L=e.key.toUpperCase();if(!done&&letters.includes(L))guess(L);else if(done&&e.key==="Enter")fb.querySelector("button.primary")?.click()};
    view(h("div",{class:"head"},h("h2",null,"🔤 Wort-Rätsel"),h("button",{class:"ghost",onclick:()=>{document.onkeydown=null;home()}},"Beenden")),h("p",{class:"small muted"},"Wort "+(k+1)+" von "+W.length+" · "+score+" Punkte"),
      h("div",{class:"panel gamebox"},h("p",{class:"small"},h("b",null,"Hinweis: "),hint),hearts,disp,kb,fb));paint()}
  function fin(){const rec=setBest("gal",score);addXP(Math.round(score/6));if(solved>=4)confetti(150);
    endScreen(rec?"🏆":"🔤",rec?"Neuer Rekord!":"Geschafft!",score+" Punkte",[{t:solved+" von "+W.length+" Wörtern erraten · +"+Math.round(score/6)+" XP"}],galgen)}
  round()}

