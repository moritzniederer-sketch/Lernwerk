/* ===== Prüfungs-Engine (aus den Trainern übernommen) ===== */
const EXT={};
const inp=(lab,ph)=>h("input",{type:"text",autocomplete:"off",spellcheck:"false","aria-label":lab,placeholder:ph||""});
const corr=(t)=>h("div",{class:"corr"},t);
/* mehrere Zeilen: Beschriftung + Eingabe */
EXT.rows={build(t,m){const ins=t.rows.map(r=>inp(r[0]));m.append(h("div",{class:"xrows"},t.rows.map((r,i)=>h("div",{class:"xrow"},h("span",{class:"xl"},r[0]),ins[i]))));
  return{get:()=>ins.map(x=>x.value),lock(){ins.forEach(x=>x.disabled=true)},mark(g){ins.forEach((x,i)=>{x.classList.add(g.ok[i]?"okf":"badf");if(!g.ok[i])x.after(corr("richtig: "+t.rows[i][2]))})}}},
 grade(t,a){const ok=t.rows.map((r,i)=>r[1].some(c=>same(a[i]||"",c)));return{s:ok.filter(Boolean).length/t.rows.length,ok}}};
/* Lückentext */
EXT.cloze={build(t,m){const ins=[];const p=h("p",{class:"clz"});t.parts.forEach(x=>{if(typeof x==="string")p.append(x);else{const i=h("input",{type:"text",class:"gap",autocomplete:"off",spellcheck:"false","aria-label":"Lücke "+(ins.length+1)});ins.push(i);p.append(i)}});m.append(p);
  return{get:()=>ins.map(x=>x.value),lock(){ins.forEach(x=>x.disabled=true)},mark(g){ins.forEach((x,i)=>{x.classList.add(g.ok[i]?"okf":"badf");if(!g.ok[i])x.after(h("span",{class:"gcorr"}," ("+g.gaps[i].show+") "))})}}},
 grade(t,a){const gaps=t.parts.filter(x=>typeof x!=="string");const ok=gaps.map((g,i)=>g.acc.some(c=>same(a[i]||"",c)));return{s:ok.filter(Boolean).length/gaps.length,ok,gaps}}};
/* Fehlertext */
EXT.fehler={build(t,m){if(t.svg){const w=document.createElement("div");w.className="tierbox";w.innerHTML=t.svg;m.append(w)}
  m.append(h("p",{class:"clz ftxt"},t.items.map(x=>x.txt+" ")));
  const rows=Array.from({length:t.n},(_,i)=>[inp("Fehler "+(i+1),"falsches Wort"),inp("Korrektur "+(i+1),"richtig wäre …")]);
  m.append(h("div",{class:"frows"},h("span",{class:"small muted"},"Fehler"),h("span",{class:"small muted"},"Korrektur"),rows.flatMap(r=>[r[0],r[1]])));
  return{get:()=>rows.map(r=>[r[0].value,r[1].value]),lock(){rows.forEach(r=>{r[0].disabled=true;r[1].disabled=true})},
   mark(g){rows.forEach((r,i)=>{const u=g.rowScore[i];r[1].classList.add(u>=1?"okf":u>0?"warnf":"badf")});m.append(corr("Die Fehler waren: "+g.errs.map(e=>"«"+e.bad+"» → «"+e.good+"»").join(", ")))}}},
 grade(t,a){const errs=t.items.filter(x=>x.wrong);const used=new Set();const rowScore=a.map(()=>0);let sum=0;
  errs.forEach(e=>{let best=-1,bs=0;a.forEach(([f,k],i)=>{if(used.has(i))return;let sc=0;if(e.acc.some(c=>same(k,c)||norm(k).includes(norm(c))))sc=1;else if(f&&(same(f,e.bad)||norm(f).includes(norm(e.bad))||norm(e.bad).includes(norm(f))&&norm(f).length>3))sc=0.25;if(sc>bs){bs=sc;best=i}});
   if(best>=0){used.add(best);rowScore[best]=bs;sum+=bs}});
  return{s:sum/errs.length,errs,rowScore}}};
/* Ankreuzen */
EXT.tick={build(t,m){const cb=t.items.map(()=>h("input",{type:"checkbox"}));m.append(h("div",{class:"ticks"},t.items.map((x,i)=>h("label",{class:"tick"},cb[i],h("span",null,x[0])))));
  return{get:()=>cb.map(c=>c.checked),lock(){cb.forEach(c=>c.disabled=true)},mark(g){cb.forEach((c,i)=>{const l=c.parentNode;l.classList.add(g.ok[i]?"tok":"tbad");l.append(h("span",{class:"small"},t.items[i][1]?"  ✓ stimmt":"  ✗ stimmt nicht"))})}}},
 grade(t,a){const ok=t.items.map((x,i)=>!!a[i]===x[1]);if(!a.some(Boolean))return{s:0,ok};return{s:ok.filter(Boolean).length/t.items.length,ok}}};
const _build=build,_grade=grade;
build=function(t,m){return EXT[t.type]?EXT[t.type].build(t,m):_build(t,m)};
grade=function(t,a){return EXT[t.type]?EXT[t.type].grade(t,a):_grade(t,a)};

function fehlerItems(pool,nWrong,total,first){
  const pick=PICK(pool,total-(first?1:0));const items=[];if(first)items.push(first);
  pick.forEach(p=>items.push({wrong:false,tpl:p.tpl,good:p.good,bad:p.bad,acc:p.acc}));
  const cand=items.map((x,i)=>i);const wr=new Set(PICK(cand,nWrong));
  items.forEach((x,i)=>{x.wrong=wr.has(i);x.txt=x.tpl.replace("{X}",x.wrong?x.bad:x.good)});return items;
}
function twoStep(btn,label,ask,action){
  if(btn.dataset.armed==="1"){clearTimeout(btn._t);btn.dataset.armed="";btn.textContent=label;btn.classList.remove("armed");action();return}
  btn.dataset.armed="1";btn.textContent=ask;btn.classList.add("armed");
  btn._t=setTimeout(()=>{btn.dataset.armed="";btn.textContent=label;btn.classList.remove("armed")},5000);
}
let EXAM_MIN=40;
let examTimer=null;
const q4=x=>Math.round(x*4)/4;
const fmtP=x=>{const w=Math.floor(x+1e-9),r=Math.round((x-w)*4);return (w||!r?String(w):"")+(r?(w?" ":"")+["","¼","½","¾"][r]:"")};
function examStart(gen){
  const ex=gen();const total=ex.A.reduce((s,a)=>s+a.parts.reduce((t,p)=>t+p.pts,0),0);
  view(h("div",{class:"panel stack"},h("h2",null,ex.kind),h("p",null,ex.A.length+" Aufgaben, "+fmtP(total)+" Punkte. Du hast "+EXAM_MIN+" Minuten Zeit."),h("p",{class:"muted"},"Lies jede Aufgabe genau. Du kannst in beliebiger Reihenfolge arbeiten und am Schluss abgeben."),
    h("div",{class:"row"},h("button",{class:"primary",onclick:()=>examRun(ex,total)},"Test starten"),h("button",{onclick:testIntro},"Zurück"))));
}
function examRun(ex,total){
  const end=Date.now()+EXAM_MIN*60000;const ctls=[];let done=false;
  const clock=h("span",{class:"clock"},EXAM_MIN+":00");const sub=h("button",{class:"primary",onclick:()=>twoStep(sub,"Abgeben","Wirklich abgeben? Nochmals tippen",()=>finish(false))},"Abgeben");
  const bar=h("div",{class:"timerbar"},h("span",null,"Verbleibende Zeit "),clock,sub);
  const blocks=ex.A.map((a,ai)=>{const pts=a.parts.reduce((t,p)=>t+p.pts,0);const sc=h("span",{class:"apts"});
    const box=h("section",{class:"aufg"},h("div",{class:"ahead"},h("b",null,"Aufgabe "+(ai+1)+(a.t?": "+a.t:"")),h("span",null,sc,"von "+fmtP(pts)+" P")),a.intro?a.intro():null);
    a.parts.forEach(p=>{const m=h("div",{class:"apart"});box.append(h("p",{class:"aq"},p.q,h("span",{class:"ppts"}," ("+fmtP(p.pts)+" P)")),m);const c=build(p.t,m);ctls.push({p,c,m,sc,ai})});
    return {box,sc,pts}});
  view(bar,h("h2",{style:"margin-top:12px"},ex.kind),blocks.map(b=>b.box));
  function tick(){const left=Math.max(0,end-Date.now());const m=Math.floor(left/60000),s=Math.floor(left%60000/1000);clock.textContent=m+":"+String(s).padStart(2,"0");
    bar.classList.toggle("late",left<5*60000);if(left<=0)finish(true)}
  examTimer=setInterval(tick,500);tick();
  function finish(auto){
    if(done)return;done=true;clearInterval(examTimer);examTimer=null;
    let P=0;const per=ex.A.map(()=>0);
    ctls.forEach(x=>{x.c.lock();const a=x.c.get();let g;try{g=grade(x.p.t,a)}catch(e){g={s:0}}const got=q4(Math.min(1,g.s||0)*x.p.pts);P+=got;per[x.ai]+=got;
      try{x.c.mark(g)}catch(e){}const sol=g.sol||(x.p.t.type==="text"?x.p.t.acc[0]:x.p.t.type==="tf"?(x.p.t.val?"Stimmt":"Stimmt nicht"):x.p.t.type==="textn"&&x.p.t.show?x.p.t.show.join(" / "):x.p.t.type==="textn"?x.p.t.groups.slice(0,x.p.t.n).map(g=>g[0]).join(", "):x.p.t.type==="order"?x.p.t.items.join(" → "):"");
      x.m.append(h("div",{class:"psc "+(got>=x.p.pts?"ok":got>0?"warn":"bad")},h("b",null,fmtP(got)+" von "+fmtP(x.p.pts)+" P"),sol&&got<x.p.pts?"  Lösung: "+sol:"",x.p.t.ex?h("div",{class:"small",style:"margin-top:4px"},x.p.t.ex):null))});
    blocks.forEach((b,i)=>{b.sc.textContent=fmtP(per[i])+" ";b.sc.className="apts "+(per[i]>=b.pts?"ok":per[i]>0?"warn":"bad")});
    P=q4(P);const note=1+5*P/total;const r=Math.round(note*2)/2;
    tests.push({d:Date.now(),p:P,m:total,note:+note.toFixed(2),r,kind:ex.kind});save("tests",tests);
    bar.remove();
    const head=h("div",{class:"panel result"},
      h("p",{class:"muted",style:"margin:0"},auto?"Die Zeit ist abgelaufen – die Prüfung wurde automatisch abgegeben.":"Prüfung abgegeben."),
      h("div",{class:"grade"},h("span",{class:"gn"},r.toFixed(1)),h("div",null,h("div",null,h("b",null,fmtP(P)+" von "+total+" Punkten")),h("div",{class:"small muted"},"genaue Note "+note.toFixed(2)+", gerundet auf halbe Noten"))),
      h("div",{class:"lzlist",style:"margin-top:10px"},ex.A.map((a,i)=>h("div",{class:"lzr"},h("span",null,"Aufgabe "+(i+1)+": "+a.t),h("span",{class:"mini"},h("i",{style:"width:"+Math.round(per[i]/blocks[i].pts*100)+"%"})),h("span",{class:"small"},fmtP(per[i])+"/"+fmtP(blocks[i].pts))))),
      h("p",{class:"small muted"},"Unten kannst du jede Aufgabe durchgehen: Grün ist richtig, Orange teilweise, Rot falsch, mit der Lösung darunter."),
      h("div",{class:"row"},h("button",{class:"primary",onclick:()=>examStart(EXAMS[ex.kind]||autoExam)},"Neue Prüfung (andere Aufgaben)"),h("button",{onclick:testIntro},"Zur Prüfungsübersicht")));
    app.prepend(head);window.scrollTo(0,0);
  }
}

/* ---------- Prüfung 3: schwierig mit Denkaufgaben ---------- */
const MQ=(q,right,wrong,pts,ex)=>({q,pts,t:mc("x",q,right,wrong,{ex})});
const KWQ=(q,groups,show,pts,ex)=>({q,pts,t:{type:"textn",kw:true,n:groups.length,groups,show,ex}});
const EXAMS={};
