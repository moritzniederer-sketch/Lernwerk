/* ===== Einfacher Aufgaben-Generator ohne KI (Demo-Modus und Notfall) + Dateien lesen ===== */
const STOP=new Set("aber alle allem allen aller alles also auch auf aus bei beim bin bis bist dabei damit dann darum das dass dein deine dem den denen denn der deren des dessen die dies diese diesem diesen dieser dieses doch dort durch eine einem einen einer eines einige einmal er es etwa euch für gab gegen geht gibt hat hatte hatten hier ihm ihn ihnen ihr ihre ihrem ihren ihrer im immer in ins ist jede jedem jeden jeder jedes jetzt kann kein keine können man mehr mit muss musste nach nicht noch nun nur oder ohne sehr sein seine seinem seinen seiner sich sie sind so sowie über um und uns unter viel viele vom von vor war waren warum was weil welche wenn wer werden wie wird wir wo wurde wurden zu zum zur zwar zwischen sodass beispiel dadurch daher deshalb jedoch sowohl dafür hatten können sollte sollen".split(" "));
const cleanLine=l=>l.replace(/^\s*([-–—•*·▪●◦]|\d{1,2}[.)]|[a-z][).])\s+/i,"").trim();
const isBullet=l=>/^\s*([-–—•*·▪●◦]|\d{1,2}[.)]|[a-z][).])\s+/i.test(l);
const words=s=>(s.match(/[A-Za-zÄÖÜäöüß][A-Za-zÄÖÜäöüß-]{2,}/g)||[]);
const stem=w=>norm(w).replace(/ /g,"").slice(0,Math.min(7,Math.max(4,norm(w).length-1)));
function keyWords(s,n){const ws=words(s).filter(w=>!STOP.has(w.toLowerCase())&&w.length>=5);const seen=new Set();const out=[];
  ws.sort((a,b)=>b.length-a.length).forEach(w=>{const k=stem(w);if(!seen.has(k)){seen.add(k);out.push(k)}});return out.slice(0,n)}
function yearOf(s){const m=s.match(/(\d{1,4})\s*(v\.\s?Chr|n\.\s?Chr)?/);if(!m)return null;let y=+m[1];if(m[2]&&/v/.test(m[2]))y=-y;return y}
function parseSummary(text){
  const raw=text.replace(/\r/g,"").split("\n").map(l=>l.replace(/\s+$/,"")).filter(l=>l.trim());
  const defs=[],sections=[],sentences=[];let cur={h:"",items:[]};
  raw.forEach((l,i)=>{const bullet=isBullet(l);const c=cleanLine(l);if(!c)return;
    const next=raw[i+1]?cleanLine(raw[i+1]):"";
    const dm=c.match(/^([^:–—=]{2,48}?)\s*(?::|–|—|=|\s-\s)\s*(.{6,})$/);
    if(dm&&dm[1].split(/\s+/).length<=5&&!/[.!?]$/.test(dm[1])){defs.push([dm[1].replace(/^[«"„]|[»"“]$/g,"").trim(),dm[2].trim()]);cur.items.push(c);return}
    const heading=!bullet&&(c.length<=70&&!/[.!?;,]$/.test(c)&&next&&(c.endsWith(":")||c.split(/\s+/).length<=8));
    if(heading){if(cur.items.length)sections.push(cur);cur={h:c.replace(/:$/,"").trim(),items:[]};return}
    cur.items.push(c)});
  if(cur.items.length)sections.push(cur);
  sections.forEach(s=>s.items.forEach(it=>it.split(/(?<=[.!?])\s+(?=[A-ZÄÖÜ«„"])/).forEach(x=>{x=x.trim();if(x.length>=25&&x.length<=240)sentences.push({s:x,h:s.h})})));
  return {defs,sections:sections.filter(s=>s.h&&s.items.length>=2),sentences};
}
function clozeOf(sent,used){
  const toks=sent.split(/(\s+)/);let best=-1,score=-1;
  toks.forEach((w,i)=>{const core=w.replace(/^[«"„(]+|[»"“).,;:!?]+$/g,"");if(!core||i===0)return;let sc=-1;
    if(/^\d{2,4}$/.test(core))sc=50;else if(/^[A-ZÄÖÜ][a-zäöüß-]{4,}$/.test(core)&&!STOP.has(core.toLowerCase()))sc=core.length+(used.has(core)?-20:0);
    if(sc>score){score=sc;best=i}});
  if(best<0||score<5)return null;const w=toks[best];const core=w.replace(/^[«"„(]+|[»"“).,;:!?]+$/g,"");const pre=w.slice(0,w.indexOf(core)),post=w.slice(w.indexOf(core)+core.length);
  used.add(core);return {word:core,parts:[toks.slice(0,best).join("")+pre,{acc:[core],show:core},post+toks.slice(best+1).join("")]};
}
function ownTasks(o){
  const P=parseSummary(o.text);const core=[],extra=[];const lz="E-"+o.id,lt=o.title;const T=t=>Object.assign(t,{lz,lzTitle:lt});
  P.defs.forEach(([term,def],i)=>{const kw=keyWords(def,3).map(k=>[k]);
    if(kw.length)core.push(T({id:o.id+"-d"+i,type:"textn",kw:true,n:Math.min(2,kw.length),q:"Erkläre: «"+term+"»",groups:kw,show:[def]}));
    extra.push(T({id:o.id+"-r"+i,type:"text",q:"Welcher Begriff ist gemeint? «"+def+"»",acc:[term]}));
    if(P.defs.length>=3){const other=R(P.defs.filter(d=>d[0]!==term));extra.push(T({id:o.id+"-f"+i,type:"tf",q:"«"+term+"»: "+other[1],val:false,ex:"Das gehört zu «"+other[0]+"». Richtig: "+def}));extra.push(T({id:o.id+"-t"+i,type:"tf",q:"«"+term+"»: "+def,val:true}))}});
  const dsh=SH(P.defs);for(let k=0;k+3<=dsh.length&&k<12;k+=4){const pr=dsh.slice(k,k+4);if(pr.length>=3)(k?extra:core).push(T({id:o.id+"-m"+k,type:"match",q:"Was gehört zusammen?",pairs:pr.map(d=>[d[0],d[1].length>110?d[1].slice(0,107)+"…":d[1]])}))}
  P.sections.forEach((s,i)=>{const its=s.items.filter(x=>x.length<=200);if(its.length<2)return;
    const defSet=new Set(P.defs.map(d=>d[0]));if(its.every(x=>[...defSet].some(d=>x.startsWith(d))))return;
    const gs=new Set();const groups=its.map(x=>keyWords(x,3)).filter(g=>{const k=g.join();if(!g.length||gs.has(k))return false;gs.add(k);return true});if(groups.length>=2)core.push(T({id:o.id+"-s"+i,type:"textn",kw:true,n:Math.min(3,groups.length),q:"«"+s.h+"»: Was weisst du dazu? Nenne "+Math.min(3,groups.length)+" Punkte.",groups,show:its}));
    const yrs=its.map(yearOf);if(its.length>=3&&yrs.filter(y=>y!==null).length===its.length){const ord=its.map((x,j)=>[x,yrs[j]]).sort((a,b)=>a[1]-b[1]).map(x=>x[0]);if(ord.length<=7)core.push(T({id:o.id+"-o"+i,type:"order",q:"«"+s.h+"»: Bring in die zeitliche Reihenfolge.",items:ord.map(x=>x.length>90?x.slice(0,87)+"…":x)}))}});
  const short=P.sections.map(s=>({h:s.h,its:s.items.filter(x=>x.length<=90)})).filter(s=>s.its.length>=2);
  for(let k=0;k<3&&short.length>=2;k++){const ss=PICK(short,Math.min(3,short.length));const items=SH(ss.flatMap(s=>PICK(s.its,2).map(x=>[x,s.h])));(k?extra:core).push(T({id:o.id+"-so"+KEY(items.map(x=>x[0])),type:"sort",q:"Zu welchem Thema gehört die Aussage?",cats:ss.map(s=>s.h),items}))}
  const used=new Set();SH(P.sentences).slice(0,40).forEach((x,i)=>{const c=clozeOf(x.s,used);if(!c)return;(core.filter(t=>t.type==="cloze").length<10?core:extra).push(T({id:o.id+"-c"+norm(x.s).slice(0,40),type:"cloze",uid:norm(x.s).slice(0,60),q:(x.h?"«"+x.h+"»: ":"")+"Ergänze die Lücke.",parts:c.parts}))});
  return {core,extra,stats:{defs:P.defs.length,sections:P.sections.length,sentences:P.sentences.length}};
}
/* ---------- Dateien lesen ---------- */
function loadScript(src){return new Promise((res,rej)=>{const s=document.createElement("script");s.src=src;s.onload=res;s.onerror=()=>rej(new Error("load"));document.head.append(s)})}
async function readOwnFile(f){const n=f.name.toLowerCase();
  if(n.endsWith(".docx")){if(!window.mammoth)await loadScript("https://cdnjs.cloudflare.com/ajax/libs/mammoth/1.6.0/mammoth.browser.min.js");
    const r=await mammoth.convertToHtml({arrayBuffer:await f.arrayBuffer()});const d=document.createElement("div");d.innerHTML=r.value;
    return Array.from(d.querySelectorAll("h1,h2,h3,h4,p,li,td")).filter(e=>!e.querySelector("p,li")).map(e=>(e.tagName==="LI"?"- ":"")+e.textContent.trim()).filter(Boolean).join("\n")}
  if(n.endsWith(".pdf")){if(!window.pdfjsLib)await loadScript("https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js");
    pdfjsLib.GlobalWorkerOptions.workerSrc="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";
    const pdf=await pdfjsLib.getDocument({data:new Uint8Array(await f.arrayBuffer())}).promise;let out=[];
    for(let i=1;i<=pdf.numPages;i++){const tc=await(await pdf.getPage(i)).getTextContent();out.push(tc.items.map(it=>it.str+(it.hasEOL?"\n":" ")).join(""))}
    const t=out.join("\n").trim();if(!t)throw new Error("In diesem PDF ist kein Text auswählbar (vermutlich ein Scan). Kopiere den Text ins Feld.");return t}
  if(/\.(txt|md)$/.test(n)||f.type.startsWith("text/"))return f.text();
  throw new Error("Dieses Format geht nicht. Nimm eine Word-Datei (.docx), ein PDF oder eine .txt-Datei – oder kopiere den Text ins Feld.");
}

/* Ergebnis des einfachen Generators ins Lernset-Format umwandeln */
function heuristicSet(title,text){const P=parseSummary(text);const b=ownTasks({id:"h",title,text});
  const all=b.core.map(t=>Object.assign(t,{extra:false})).concat(b.extra.map(t=>Object.assign(t,{extra:true})));
  const lern=[];const bySec={};
  P.sections.forEach((s,i)=>{const id="L"+(i+1);lern.push({id,titel:s.h,beschreibung:"",info:s.items.slice(0,12)});bySec[s.h]=id});
  if(!lern.length)lern.push({id:"L1",titel:title,beschreibung:"",info:text.split("\n").filter(x=>x.trim()).slice(0,12)});
  const firstId=lern[0].id;
  const aufgaben=all.map(t=>{let lz=firstId;const m=(t.q||"").match(/^«([^»]+)»/);if(m&&bySec[m[1]])lz=bySec[m[1]];const c=Object.assign({},t,{lz});delete c.lzTitle;return c});
  return {titel:title,lernziele:lern,aufgaben,begriffe:P.defs.map(([b,e])=>({begriff:b,erklaerung:e,stichwoerter:keyWords(e,3).map(k=>[k])})),ereignisse:[],raetsel:[],quelle:"einfach"}}
