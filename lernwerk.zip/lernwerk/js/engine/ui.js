/* ===== Trainer ===== */
const app=document.getElementById("app");
function h(t,a,...k){const e=document.createElement(t);if(a)for(const[x,v]of Object.entries(a)){if(v==null||v===false)continue;if(x==="class")e.className=v;else if(x.startsWith("on"))e.addEventListener(x.slice(2),v);else e.setAttribute(x,v===true?"":v)}for(const c of k.flat(Infinity)){if(c==null||c===false)continue;e.append(c instanceof Node?c:String(c))}return e}
const APP=(typeof APPCFG!=="undefined")?APPCFG:{title:"",sub:"",prefix:"lp:"};
function load(k,d){try{return JSON.parse(localStorage.getItem(APP.prefix+k))??d}catch(e){return d}}
function save(k,v){try{localStorage.setItem(APP.prefix+k,JSON.stringify(v))}catch(e){}}
let seen=load("seen",{});      // id -> wie oft gesehen (Üben)
let tseen=load("tseen",{});    // id -> wie oft im Test
let ok=load("ok",{});          // id -> zuletzt richtig?
let lzStat=load("lz",{});      // Lernziel -> {r,n}
let tests=load("tests",[]);
function view(...k){app.replaceChildren(...k.flat(Infinity).filter(Boolean));window.scrollTo(0,0)}

/* ---------- Aufgabenpools ---------- */
function bank(id){const b=GEN[id]();b.core.forEach(t=>t.lz=id);b.extra.forEach(t=>t.lz=id);return b}
/* Inhalt einer Aufgabe: gleiche Frage = gleiche Aufgabe, auch wenn sie neu erzeugt wurde */
const ck=t=>["sort","match","label","plabel"].includes(t.type)?t.id:t.type+"|"+t.q+(t.img?"|"+t.img:"")+(t.leg?"|"+t.leg:"")+(t.foto?"|"+t.foto:"")+(t.quelle?"|"+t.quelle:"")+(t.uid?"|"+t.uid:"");
let ts=load("ts",{});
function weight(t,counter){const k=ck(t);const age=(Date.now()-(ts[k]||0))/60000;return (counter[k]||0)*10+(age<45?25:age<240?8:0)+Math.random()*9}
function freshPick(list,n,counter){
  /* zuerst nie gesehene, dann am seltensten und am längsten nicht mehr gesehene; jeden Inhalt nur einmal */
  const by={};list.forEach(t=>{const k=ck(t);if(!by[k])by[k]=t});
  return Object.values(by).map(t=>[t,weight(t,counter)]).sort((a,b)=>a[1]-b[1]).slice(0,n).map(x=>x[0]);
}
function mark(t,s){const k=ck(t);seen[k]=(seen[k]||0)+1;ts[k]=Date.now();ok[k]=s>=1}

/* ---------- Antworten prüfen ---------- */
const norm=s=>String(s).toLowerCase().replace(/ä/g,"ae").replace(/ö/g,"oe").replace(/ü/g,"ue").replace(/ß/g,"ss").normalize("NFD").replace(/[̀-ͯ]/g,"").replace(/[^a-z0-9 ]+/g," ").replace(/\b(der|die|das|den|dem|ein|eine|einer|eines)\b/g," ").replace(/\s+/g," ").trim();
function lev(a,b){const m=a.length,n=b.length;if(!m)return n;if(!n)return m;let p=Array.from({length:n+1},(_,j)=>j);for(let i=1;i<=m;i++){const c=[i];for(let j=1;j<=n;j++)c[j]=Math.min(p[j]+1,c[j-1]+1,p[j-1]+(a[i-1]===b[j-1]?0:1));p=c}return p[n]}
function same(inp,cand){const x=norm(inp),c=norm(cand);if(!x||!c)return false;if(x===c||x.replace(/ /g,"")===c.replace(/ /g,""))return true;const tol=c.length>=10?2:c.length>=5?1:0;if(lev(x,c)<=tol)return true;
  const xw=x.split(" ");if(c.length>=5&&xw.length<=c.split(" ").length+3&&(" "+x+" ").includes(" "+c+" "))return true;return false}
const parts=s=>String(s).split(/,|;|\/|\bund\b|\n/).map(x=>x.trim()).filter(Boolean);

/* ---------- Aufgabentypen: bauen, Antwort holen, bewerten, zeigen ---------- */
const TYPELAB={plabel:"Skelett beschriften",foto:"Foto erkennen",zelle:"Zellschicht und Aufgabe",stamm:"Merkmale und Tiere",label:"Beschriften",text:"Eintippen",textn:"Eintippen",mc:"Auswählen",tf:"Stimmt das?",match:"Zuordnen",sort:"Sortieren",order:"Reihenfolge"};
function build(t,mount){
  const box=h("div");
  if(t.type==="text"||t.type==="textn"){
    const inp=t.kw?h("textarea",{rows:"4",spellcheck:"false","aria-label":"Antwort",placeholder:"Ein Merkmal pro Zeile oder mit Komma getrennt"}):h("input",{type:"text",autocomplete:"off",spellcheck:"false","aria-label":"Antwort",placeholder:t.type==="textn"?"Antworten mit Komma trennen":""});
    if(t.quelle&&typeof QUELLEN!=="undefined"){const Q=QUELLEN.find(q=>q.id===t.quelle);if(Q)box.append(quelleNode(Q)())}
    if(t.img||t.leg){const w=document.createElement("div");w.className="tierbox";w.innerHTML=t.img?tierSVG(t.img):beinSVG(t.leg);box.append(w)}
    box.append(inp);mount.append(box);
    return{focus:()=>inp.focus(),get:()=>inp.value,lock(){inp.disabled=true},mark(g){inp.classList.add(g.s>=1?"okf":g.s>0?"warnf":"badf")}};
  }
  if(t.type==="mc"||t.type==="tf"){
    const opts=t.type==="tf"?["Stimmt","Stimmt nicht"]:t.opts;const sel=new Set();
    const bs=opts.map((o,i)=>h("button",{class:"opt","aria-pressed":"false",onclick:()=>{if(t.type==="tf"||!t.multi){sel.clear();bs.forEach(b=>b.setAttribute("aria-pressed","false"))}
      if(sel.has(i)){sel.delete(i);bs[i].setAttribute("aria-pressed","false")}else{sel.add(i);bs[i].setAttribute("aria-pressed","true")}}},o));
    box.append(t.multi?h("p",{class:"small muted",style:"margin:0 0 8px"},"Mehrere Antworten können richtig sein."):null,h("div",{class:"opts"},bs));mount.append(box);
    return{focus:()=>{},get:()=>[...sel],lock(){bs.forEach(b=>b.disabled=true)},mark(){const right=t.type==="tf"?[t.val?0:1]:t.ok;bs.forEach((b,i)=>{if(right.includes(i))b.classList.add("right");else if(sel.has(i))b.classList.add("wrong")})}};
  }
  if(t.type==="match"||t.type==="sort"){
    const rows=t.type==="match"?t.pairs.map(p=>[p[0],p[1]]):t.items;
    const choices=t.type==="match"?SH([...new Set(t.pairs.map(p=>p[1]))]):t.cats;
    const ss=rows.map(r=>h("select",{"aria-label":r[0]},h("option",{value:""},"– wählen –"),choices.map(c=>h("option",{value:c},c))));
    box.append(h("div",{class:"mt"},rows.map((r,i)=>h("div",{class:"mrow"},h("span",{class:"ml"},r[0]),ss[i]))));mount.append(box);
    return{focus:()=>{},get:()=>ss.map(s=>s.value),lock(){ss.forEach(s=>s.disabled=true)},mark(){ss.forEach((s,i)=>{const good=s.value===rows[i][1];s.classList.add(good?"okf":"badf");if(!good)s.after(h("div",{class:"corr"},"richtig: "+rows[i][1]))})}};
  }
  if(t.type==="plabel"){
    const marks=t.names.map((n,i)=>[i+1,n]);const w=document.createElement("div");w.className="diagwrap";w.innerHTML=picSVG(t.pic,marks);
    const ins=t.names.map((n,i)=>h("input",{type:"text",autocomplete:"off",spellcheck:"false","aria-label":"Nummer "+(i+1)}));
    box.append(w,h("p",{class:"small muted",style:"margin:0 0 8px"},"Verwende die Knochennamen wie beim Skelett des Menschen."),h("div",{class:"lbl"},ins.map((x,i)=>h("div",{class:"lrow"},h("span",{class:"lnum"},i+1),x))));mount.append(box);
    ins.forEach((x,i)=>x.addEventListener("keydown",e=>{if(e.key==="Enter"&&i<ins.length-1){e.preventDefault();e.stopPropagation();ins[i+1].focus()}}));
    return{focus:()=>ins[0].focus(),get:()=>ins.map(x=>x.value),lock(){ins.forEach(x=>x.disabled=true)},mark(){ins.forEach((x,i)=>{const n=t.names[i];const g=(PICACC[n]||[n]).some(c=>same(x.value,c));x.classList.add(g?"okf":"badf");if(!g)x.after(h("div",{class:"corr"},"richtig: "+picShow(n)))})}};
  }
  if(t.type==="foto"){
    const F=FOTOS[t.foto];const img=h("img",{src:F.src,alt:"Foto eines Lebewesens",class:"foto"});
    const si=h("input",{type:"text",autocomplete:"off",spellcheck:"false","aria-label":"Stamm",placeholder:"Stamm"});
    const ki=h("input",{type:"text",autocomplete:"off",spellcheck:"false","aria-label":"Klasse",placeholder:"nur bei Gliederfüssern"});
    box.append(h("div",{class:"fotobox"},img),h("div",{class:"lbl"},h("div",null,h("label",{class:"flab"},"Stamm"),si),h("div",null,h("label",{class:"flab"},"Klasse (nur Gliederfüsser)"),ki)));mount.append(box);
    si.addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();e.stopPropagation();ki.focus()}});
    return{focus:()=>si.focus(),get:()=>[si.value,ki.value],lock(){si.disabled=true;ki.disabled=true},mark(g){si.classList.add(g.okS?"okf":"badf");if(!g.okS)si.after(h("div",{class:"corr"},"richtig: "+F.stamm));
      if(F.kl){ki.classList.add(g.okK?"okf":"badf");if(!g.okK)ki.after(h("div",{class:"corr"},"richtig: "+F.kl))}else if(ki.value.trim()){ki.classList.add("warnf");ki.after(h("div",{class:"corr"},"kein Gliederfüsser – keine Klasse nötig"))}}};
  }
  if(t.type==="zelle"){
    const li=h("input",{type:"text",autocomplete:"off",spellcheck:"false","aria-label":"Zellschicht",placeholder:"Ektoderm oder Entoderm?"});
    const fa=h("textarea",{rows:"3",spellcheck:"false","aria-label":"Aufgabe",placeholder:"Wofür ist sie zuständig?"});
    box.append(h("label",{class:"flab"},"Zellschicht"),li,h("label",{class:"flab"},"Aufgabe"),fa);mount.append(box);
    return{focus:()=>li.focus(),get:()=>[li.value,fa.value],lock(){li.disabled=true;fa.disabled=true},mark(g){li.classList.add(g.sl?"okf":"badf");fa.classList.add(g.sf>=1?"okf":g.sf>0?"warnf":"badf");
      if(!g.sl)li.after(h("div",{class:"corr"},"richtig: "+t.c.l));if(g.sf<1)fa.after(h("div",{class:"corr"},"richtig: "+t.c.f))}};
  }
  if(t.type==="stamm"){
    const ta=(lab,ph)=>h("textarea",{rows:"4",spellcheck:"false","aria-label":lab,placeholder:ph});
    const m=ta("Merkmale","Ein Merkmal pro Zeile oder mit Komma getrennt"),b=ta("Tiergruppen","z. B. eine Tiergruppe pro Zeile");
    box.append(h("label",{class:"flab"},"Merkmale ("+t.show.length+")"),m,h("label",{class:"flab"},"Tiergruppen ("+t.b.length+")"),b);mount.append(box);
    return{focus:()=>m.focus(),get:()=>[m.value,b.value],lock(){m.disabled=true;b.disabled=true},mark(g){m.classList.add(g.sm>=1?"okf":g.sm>0?"warnf":"badf");b.classList.add(g.sb>=1?"okf":g.sb>0?"warnf":"badf");
      if(g.sm<1)m.after(h("div",{class:"corr"},"Es fehlt: "+g.missM.join(", ")));if(g.sb<1)b.after(h("div",{class:"corr"},"Es fehlt: "+g.missB.join(", ")))}};
  }
  if(t.type==="label"){
    const marks=t.names.map((n,i)=>[i+1,n]);
    const ins=t.names.map((n,i)=>h("input",{type:"text",autocomplete:"off",spellcheck:"false","aria-label":"Nummer "+(i+1)}));
    box.append(svgDiag(t.diag,marks,false),h("div",{class:"lbl"},ins.map((x,i)=>h("div",{class:"lrow"},h("span",{class:"lnum"},i+1),x))));mount.append(box);
    ins.forEach((x,i)=>x.addEventListener("keydown",e=>{if(e.key==="Enter"&&i<ins.length-1){e.preventDefault();e.stopPropagation();ins[i+1].focus()}}));
    return{focus:()=>ins[0].focus(),get:()=>ins.map(x=>x.value),lock(){ins.forEach(x=>x.disabled=true)},mark(){ins.forEach((x,i)=>{const g=syn(t.names[i]).some(c=>same(x.value,c));x.classList.add(g?"okf":"badf");if(!g)x.after(h("div",{class:"corr"},"richtig: "+t.names[i]))})}};
  }
  if(t.type==="order"){
    let items=SH(t.items);if(items.join()===t.items.join())items=items.slice(1).concat(items[0]);
    const ol=h("ol",{class:"order"});let locked=false;
    const draw=marks=>ol.replaceChildren(...items.map((it,i)=>h("li",{class:marks?(marks[i]?"right":"wrong"):""},h("span",{class:"pos"},i+1),h("span",{class:"txt"},it),
      h("button",{class:"mv","aria-label":it+" nach oben",disabled:locked||i===0,onclick:()=>{[items[i-1],items[i]]=[items[i],items[i-1]];draw()}},"▲"),
      h("button",{class:"mv","aria-label":it+" nach unten",disabled:locked||i===items.length-1,onclick:()=>{[items[i+1],items[i]]=[items[i],items[i+1]];draw()}},"▼"))));
    draw();box.append(h("p",{class:"small muted",style:"margin:0 0 8px"},"Verschiebe mit den Pfeilen."),ol);mount.append(box);
    return{focus:()=>{},get:()=>items.slice(),lock(){locked=true;draw()},mark(){draw(items.map((x,i)=>x===t.items[i]));if(items.join()!==t.items.join())ol.after(h("div",{class:"corr"},"richtig: "+t.items.join(" → ")))}};
  }
}
function grade(t,a){
  if(t.type==="text"){const s=t.acc.some(c=>same(a,c))?1:0;return{s,sol:t.acc[0]}}
  if(t.type==="plabel"){const r=t.names.filter((n,i)=>(PICACC[n]||[n]).some(c=>same(a[i]||"",c))).length;return{s:r/t.names.length,sol:t.names.map((n,i)=>(i+1)+" "+picShow(n)).join(", ")}}
  if(t.type==="foto"){const F=FOTOS[t.foto];const [as,ak]=a||["",""];const okS=stOf(F.stamm).acc.some(c=>same(as,c));const okK=F.kl?kacc(F.kl).some(c=>same(ak,c)):true;
    return{s:F.kl?((okS?1:0)+(okK?1:0))/2:(okS?1:0),okS,okK,sol:F.name+": "+F.stamm+(F.kl?", Klasse "+F.kl:""),full2:true}}
  if(t.type==="zelle"){const [al,af]=a||["",""];const c=t.c;const sl=LACC[c.l].concat(c.z==="Nervenzelle"?NERV_EXTRA:[]).some(x=>same(al,x)||norm(al).includes(norm(x)))&&!norm(al).includes(norm(c.l==="Ektoderm"?"Entoderm":"Ektoderm"))?1:0;
    const hit=new Set();const x=norm(af);c.kw.forEach((g,gi)=>{if(g.some(k=>x.includes(norm(k))))hit.add(gi)});const sf=hit.size/c.kw.length;
    return{s:(sl+sf)/2,sl,sf,sol:c.z+" liegt im "+c.l+" und "+c.f,full2:true}}
  if(t.type==="stamm"){const [am,ab]=a||["",""];const hit=new Set();parts(am).forEach(p=>{const x=norm(p);t.groups.forEach((g,gi)=>{if(g.some(k=>x.includes(norm(k))))hit.add(gi)})});
    const hb=new Set();parts(ab).forEach(p=>t.b.forEach((x,i)=>{if([x,x.replace(/n$/,""),x.replace(/e$/,""),x.replace(/en$/,""),x.replace(/ien$/,""),x.replace(/ä/,"a")].some(v=>same(p,v)))hb.add(i)}));
    const sm=hit.size/t.groups.length,sb=hb.size/t.b.length;const missM=t.show.filter((x,i)=>!hit.has(i)),missB=t.b.filter((x,i)=>!hb.has(i));
    return{s:(hit.size+hb.size)/(t.groups.length+t.b.length),sm,sb,missM,missB,sol:"Merkmale: "+t.show.join("; ")+". Tiergruppen: "+t.b.join(", "),full2:true}}
  if(t.type==="textn"&&t.kw){const hit=new Set();parts(a).forEach(p=>{const x=norm(p);t.groups.forEach((g,gi)=>{if(g.some(k=>x.includes(norm(k))))hit.add(gi)})});
    if(t.show.length!==t.groups.length)return{s:Math.min(1,hit.size/t.n),full2:true,sol:"Musterlösung: "+t.show.join(" ")};const miss=t.show.filter((m,i)=>!hit.has(i));return{s:Math.min(1,hit.size/t.n),sol:hit.size>=t.n?t.show.join(", "):"es fehlt: "+miss.join(", "),full:t.show.join("; ")}}
  if(t.type==="textn"){const ps=parts(a),hit=new Set();ps.forEach(p=>t.groups.forEach((g,gi)=>{if(g.some(c=>same(p,c)))hit.add(gi)}));return{s:Math.min(hit.size,t.n)/t.n,sol:(t.groups.length>t.n?"z. B. ":"")+t.groups.slice(0,Math.max(t.n,t.groups.length>t.n?t.n+1:t.n)).map(g=>g[0]).join(", ")}}
  if(t.type==="tf"){const s=a.length===1&&a[0]===(t.val?0:1)?1:0;return{s,sol:t.val?"Stimmt":"Stimmt nicht"}}
  if(t.type==="mc"){const A=new Set(a);let s;if(!t.multi)s=A.size===1&&t.ok.includes(a[0])?1:0;else{let r=0;t.ok.forEach(i=>{if(A.has(i))r++});const w=[...A].filter(i=>!t.ok.includes(i)).length;s=Math.max(0,(r-w)/t.ok.length)}return{s,sol:t.ok.map(i=>t.opts[i]).join(" / ")}}
  if(t.type==="match"||t.type==="sort"){const rows=t.type==="match"?t.pairs:t.items;const r=rows.filter((x,i)=>a[i]===x[1]).length;return{s:r/rows.length,sol:""}}
  if(t.type==="label"){const r=t.names.filter((n,i)=>syn(n).some(c=>same(a[i]||"",c))).length;return{s:r/t.names.length,sol:t.names.map((n,i)=>(i+1)+" "+n).join(", ")}}
  if(t.type==="order"){const r=a.filter((x,i)=>x===t.items[i]).length;return{s:a.join()===t.items.join()?1:r/t.items.length*0.75,sol:t.items.join(" → ")}}
}
const pts=t=>t.type==="stamm"?3:t.type==="zelle"?2:t.denk?2:(["match","sort","order","textn","label"].includes(t.type)?2:1);
function filled(t,a){if(Array.isArray(a))return t.type==="order"||a.some(x=>x!==""&&x!=null);return String(a).trim()!==""}

/* ---------- eine Aufgabe zeigen ---------- */
function taskView(t,{mode,label},done){
  const lz=LZ.find(l=>l.id===t.lz)||{id:"",t:t.lzTitle||"Eigene Zusammenfassung"};
  const mount=h("div"),fb=h("div");
  const head=h("p",{class:"tag"},h("span",null,lz.id+" "+lz.t),t.denk?h("span",{class:"denk"},"Denkaufgabe"):null,h("span",{class:"tt"},TYPELAB[t.type]));
  const ctl=build(t,mount);
  const go=h("button",{class:"primary"},mode==="test"?"Antwort speichern":"Prüfen");
  const skip=h("button",{class:"ghost"},mode==="test"?"Überspringen":"Weiss ich nicht");
  let fin=false;
  function check(force){
    if(fin)return;const a=ctl.get();
    if(!force&&!filled(t,a)){toast("Gib zuerst eine Antwort ein.");return}
    fin=true;ctl.lock();
    if(mode==="test"){done(a);return}
    const g=force?{s:0,sol:grade(t,a).sol}:grade(t,a);ctl.mark(g);go.disabled=true;skip.disabled=true;
    const msg=g.s>=1?"Richtig.":g.s>0?"Teilweise richtig.":"Leider falsch.";
    const sol=g.full2?" "+g.sol+".":(t.kw&&g.full)?" Alle Merkmale: "+g.full+(g.s<1?" ("+g.sol+")":"")+".":(g.s<1&&g.sol&&["text","textn","tf","mc","label"].includes(t.type))?" Richtig: "+g.sol+".":"";
    const nx=h("button",{class:"primary",style:"margin-top:12px",onclick:()=>{document.onkeydown=null;done(g.s)}},"Weiter");
    fb.replaceChildren(h("div",{class:"fb "+(g.s>=1?"ok":g.s>0?"warn":"bad")},h("strong",null,msg),sol,t.ex?h("div",{style:"margin-top:6px"},t.ex):null),nx);
    nx.focus();document.onkeydown=e=>{if(e.key==="Enter"){e.preventDefault();nx.click()}};
  }
  go.onclick=()=>check(false);skip.onclick=()=>check(true);
  document.onkeydown=e=>{if(e.key==="Enter"&&!fin&&e.target.tagName==="INPUT"){e.preventDefault();check(false)}};
  const node=h("div",null,head,label?h("p",{class:"small muted",style:"margin:0 0 4px"},label):null,h("p",{class:"q"},t.q),mount,h("div",{class:"row",style:"margin-top:14px"},go,skip),fb);
  return{node,focus:ctl.focus||(()=>{})};
}
let toastT;function toast(m){const e=document.getElementById("toast");e.textContent=m;e.hidden=false;clearTimeout(toastT);toastT=setTimeout(()=>e.hidden=true,2200)}

/* ---------- Runde (Üben) ---------- */
function shell(title,onQuit){
  const bar=h("span"),cnt=h("span",{class:"small muted"}),body=h("div");
  view(h("div",{class:"head"},h("h2",null,title),h("div",{class:"row"},cnt,h("button",{class:"ghost",onclick:()=>{document.onkeydown=null;(onQuit||home)()}},"Beenden"))),h("div",{class:"bar"},bar),body);
  return{body,prog(d,n){bar.style.width=(d/Math.max(1,n)*100)+"%";cnt.textContent=d+" von "+n}};
}
function practice(title,tasks,again,backupPool){
  const ui=shell(title);const total=tasks.length;let i=0,score=0,first=0;const wrongLz={};const retried=new Set();
  function step(){
    if(i>=tasks.length){save("seen",seen);save("ok",ok);save("lz",lzStat);save("ts",ts);return practiceEnd(title,first,total,wrongLz,again)}
    ui.prog(Math.min(i,total),total);
    const t=tasks[i];
    const tv=taskView(t,{mode:"practice",label:t._retry?"Nochmal üben, diesmal eine andere Aufgabe":null},s=>{
      mark(t,s);
      const st=lzStat[t.lz]||(lzStat[t.lz]={r:0,n:0});st.n++;st.r+=s;
      if(!t._retry){score+=s;if(s>=1)first++;else{wrongLz[t.lz]=(wrongLz[t.lz]||0)+1;
        if(!retried.has(t.id)){retried.add(t.id);const pool=(backupPool?backupPool(t.lz):bank(t.lz).extra).filter(x=>ck(x)!==ck(t)&&!tasks.some(y=>ck(y)===ck(x)));
          const nt=freshPick(pool,1,seen)[0]||Object.assign({},t);nt._retry=true;tasks.splice(Math.min(tasks.length,i+4),0,nt)}}}
      i++;if(i%5===0){save("seen",seen);save("ok",ok);save("lz",lzStat);save("ts",ts)}step();
    });
    ui.body.replaceChildren(tv.node);tv.focus();
  }
  step();
}
function practiceEnd(title,first,total,wrongLz,again){
  const weak=Object.entries(wrongLz).sort((a,b)=>b[1]-a[1]);
  view(h("h2",null,title+": geschafft"),h("p",{class:"score"},first+" / "+total),h("p",{class:"muted"},"Aufgaben beim ersten Versuch richtig. Falsche Aufgaben hast du in einer anderen Form nochmal geübt."),
    weak.length?h("div",{class:"panel"},h("h3",null,"Hier lohnt sich noch Übung"),weak.map(([id,n])=>{const l=LZ.find(x=>x.id===id);if(!l)return null;return h("div",{class:"row",style:"justify-content:space-between;margin-top:8px"},h("span",null,l.id+" "+l.t+" ("+n+" falsch)"),h("button",{onclick:()=>lzPage(id)},"Üben"))})):null,
    h("div",{class:"row",style:"margin-top:20px"},h("button",{class:"primary",onclick:again},"Nochmal (neue Aufgaben)"),h("button",{onclick:home},"Zur Übersicht")));
}
function lzPage(id){
  document.onkeydown=null;
  const l=LZ.find(x=>x.id===id),inf=INFO[id]||{f:[]},b=bank(id),n=b.core.length+Math.min(6,b.extra.length);
  view(h("div",{class:"head"},h("button",{class:"ghost",onclick:home},"Alle Lernziele"),null),
    h("p",{class:"lid2"},l.id),h("h1",{class:"h1s"},l.t),
    l.add?h("p",{class:"note"},l.add===true?"Dieses Lernziel steht nicht in deiner Zusammenfassung. Der Inhalt ist aus dem Schulstoff ergänzt – vergleiche ihn mit deinem Heft oder Buch.":"Die Knochenformen stammen aus deiner Zusammenfassung, die Knochennamen am Skelett sind ergänzt."):null,
    h("div",{class:"panel"},h("h3",null,"Das musst du wissen"),h("ul",{class:"facts"},inf.f.map(x=>h("li",null,x)))),
    (inf.svgs||[]).map(s=>{const w=document.createElement("div");w.className="diagwrap";w.innerHTML=s.html();return h("div",{class:"panel"},h("h3",null,s.t),w)}),
    inf.img?h("div",{class:"panel"},h("h3",null,inf.img.t),h("img",{src:inf.img.src(),alt:inf.img.t,style:"width:100%;border-radius:10px;display:block"})):null,
    inf.table?h("div",{class:"panel"},h("table",{class:"xtab"},h("thead",null,h("tr",null,inf.table.head.map(x=>h("th",null,x)))),h("tbody",null,inf.table.rows.map(r=>h("tr",null,r.map(c=>h("td",null,c))))))):null,
    inf.tiere?h("div",{class:"panel"},h("h3",null,"So sehen die vier Klassen aus"),h("div",{class:"tgal"},inf.tiere.map(k=>{const w=h("figure",{class:"tfig"});w.innerHTML=tierSVG(k,true);w.append(h("figcaption",null,h("b",null,TIERINFO[k][1]),": "+TIERINFO[k][2]));return w}))):null,
    inf.pics?inf.pics.map(k=>{const w=document.createElement("div");w.className="diagwrap";const mk=Object.keys(PICS[k].marks).map((n,i)=>[i+1,n]);w.innerHTML=picSVG(k,mk);
      return h("div",{class:"panel"},h("h3",null,PICS[k].title),w,h("ol",{class:"legend"},mk.map(([l,n])=>h("li",null,h("b",null,l)," "+picShow(n)))))}):null,
    inf.beine?h("div",{class:"panel"},h("h3",null,"Die acht Beintypen"),h("div",{class:"tgal"},inf.beine.map(k=>{const w=h("figure",{class:"tfig"});w.innerHTML=beinSVG(k,true);w.append(h("figcaption",null,h("b",null,BEININFO[k][0]),": "+BEININFO[k][3]+" ("+BEININFO[k][2]+")"));return w}))):null,
    (inf.d||[]).map(k=>h("div",{class:"panel"},h("h3",null,DIAG[k].title),svgDiag(k,Object.keys(DIAG[k].marks).map((nm,i)=>[i+1,nm]),true))),
    (()=>{const open=b.core.filter(t=>!ok[ck(t)]).length;const started=b.core.some(t=>seen[ck(t)]);
      return h("div",{class:"row",style:"margin-top:20px"},started?h("button",{class:"primary",onclick:()=>lzRound(id,true)},"Neue und falsche Aufgaben"+(open?" ("+open+" offen)":"")):null,h("button",{class:started?"":"primary",onclick:()=>lzRound(id)},"Alle Aufgaben üben ("+n+")"),h("button",{onclick:home},"Zurück"))})());
}
function lzRound(id,onlyNew){
  const b=bank(id);
  let tasks;
  if(onlyNew){
    /* noch nicht gekonnte Grundaufgaben + neue Zusatzaufgaben, auffüllen mit am längsten nicht gesehenen */
    const open=b.core.filter(t=>!ok[ck(t)]);
    const extra=freshPick(b.extra,Math.min(8,b.extra.length),seen);
    tasks=open.concat(extra);
    if(tasks.length<10)tasks=tasks.concat(freshPick(b.core.filter(t=>!open.includes(t)),10-tasks.length,seen));
    tasks=SH(tasks);
  }else{
    /* alle Grundaufgaben + die am wenigsten gesehenen Zusatzaufgaben */
    const extra=freshPick(b.extra,Math.min(6,b.extra.length),seen);
    tasks=SH(b.core).concat(SH(extra));
  }
  const l=LZ.find(x=>x.id===id);
  practice(l.id+" "+l.t,tasks,()=>lzRound(id,onlyNew));
}
function mixRound(){
  const all=LZ.map(l=>bank(l.id));
  const tasks=[];
  /* aus jedem Lernziel mindestens eine, Rest nach Schwäche und Neuheit */
  SH(LZ.map((l,k)=>k)).slice(0,12).forEach(k=>tasks.push(freshPick(all[k].core.concat(all[k].extra),1,seen)[0]));
  const rest=all.flatMap(b=>b.core.concat(b.extra)).filter(t=>!tasks.some(x=>x.id===t.id));
  const weakScore=t=>{const s=lzStat[t.lz];return s&&s.n?1-s.r/s.n:0.5};
  const ranked=rest.map(t=>[t,weight(t,seen)-weakScore(t)*6]).sort((a,b)=>a[1]-b[1]).map(x=>x[0]);
  const ids=new Set(tasks.map(ck));for(const t of ranked){if(tasks.length>=16)break;if(!ids.has(ck(t))){ids.add(ck(t));tasks.push(t)}}
  practice("Gemischte Übung",SH(tasks),mixRound);
}

/* ---------- Test ---------- */
function testIntro(){
  view(h("div",{class:"head"},h("h2",null,"Test"),h("button",{class:"ghost",onclick:home},"Zurück")),
    h("div",{class:"panel stack"},
      h("p",null,"20 Aufgaben aus allen 15 Lernzielen, darunter etwa 6 schwierigere Denkaufgaben und Beschriftungen von Zeichnungen. Du bekommst erst am Ende die Auswertung und eine Note von 1 bis 6."),
      h("p",{class:"muted"},"Jeder neue Test nimmt zuerst Aufgaben, die in deinen bisherigen Tests noch nicht vorkamen."),
      h("p",{class:"muted"},"Punkte: einfache Aufgaben 1 Punkt; Zuordnen, Sortieren, Reihenfolge, Beschriften und Denkaufgaben 2 Punkte. Teilpunkte sind möglich."),
      h("button",{class:"primary",onclick:testRun},"Test starten")),
    tests.length?h("div",{class:"panel"},h("h3",null,"Bisherige Tests"),h("div",{class:"hist"},tests.slice(-8).reverse().map(x=>h("div",null,h("b",null,"Note "+x.note.toFixed(1)),"  "+x.p+" / "+x.m+" Punkte, "+new Date(x.d).toLocaleDateString("de-CH"))))):null);
}
function testRun(){
  const all=LZ.map(l=>bank(l.id));const pool=all.flatMap(b=>b.core.concat(b.extra));
  const denk=pool.filter(t=>t.denk),norm_=pool.filter(t=>!t.denk);
  const tasks=[];const ids=new Set();const add=t=>{if(t&&!ids.has(ck(t))){ids.add(ck(t));tasks.push(t)}};
  const both={};Object.keys(seen).forEach(k=>both[k]=(seen[k]||0)*0.3);Object.keys(tseen).forEach(k=>both[k]=(both[k]||0)+tseen[k]);
  /* 6 Denkaufgaben aus verschiedenen Lernzielen */
  const dz=SH(LZ.map(l=>l.id));for(const id of dz){if(tasks.length>=6)break;add(freshPick(denk.filter(t=>t.lz===id),1,both)[0])}
  /* jedes Lernziel mindestens einmal */
  LZ.forEach(l=>{if(!tasks.some(t=>t.lz===l.id))add(freshPick(norm_.filter(t=>t.lz===l.id),1,both)[0])});
  /* auffüllen bis 20, abwechslungsreiche Typen */
  const rest=freshPick(norm_.filter(t=>!ids.has(ck(t))),60,both);const tc={};tasks.forEach(t=>tc[t.type]=(tc[t.type]||0)+1);
  for(const t of rest){if(tasks.length>=20)break;if((tc[t.type]||0)>=5||(t.type==="label"&&(tc.label||0)>=3))continue;tc[t.type]=(tc[t.type]||0)+1;add(t)}
  const order=SH(tasks);const answers=[];let i=0;
  const ui=shell("Test",()=>home());
  function show(){
    if(i>=order.length)return testEnd(order,answers);
    ui.prog(i,order.length);
    const tv=taskView(order[i],{mode:"test",label:"Aufgabe "+(i+1)+" von "+order.length+", "+pts(order[i])+(pts(order[i])>1?" Punkte":" Punkt")},a=>{answers[i]=a;i++;show()});
    ui.body.replaceChildren(tv.node);tv.focus();
  }
  show();
}
function testEnd(order,answers){
  document.onkeydown=null;
  let p=0,m=0;const rows=[];const byLz={};
  order.forEach((t,i)=>{const a=answers[i];const g=filled(t,a)?grade(t,a):{s:0,sol:grade(t,a).sol};const pt=pts(t);p+=g.s*pt;m+=pt;
    tseen[ck(t)]=(tseen[ck(t)]||0)+1;mark(t,g.s);
    const st=lzStat[t.lz]||(lzStat[t.lz]={r:0,n:0});st.n++;st.r+=g.s;
    const b=byLz[t.lz]||(byLz[t.lz]={p:0,m:0});b.p+=g.s*pt;b.m+=pt;rows.push([t,a,g,pt])});
  const note=Math.min(6,Math.max(1,1+5*p/m));const round=Math.round(note*2)/2;
  tests.push({d:Date.now(),p:+p.toFixed(1),m,note:+note.toFixed(2)});
  save("tseen",tseen);save("seen",seen);save("ok",ok);save("lz",lzStat);save("tests",tests);save("ts",ts);
  const ansText=(t,a)=>{if(!filled(t,a))return"(keine Antwort)";if(t.type==="tf")return a[0]===0?"Stimmt":"Stimmt nicht";if(t.type==="mc")return a.map(i=>t.opts[i]).join(" / ");if(t.type==="order")return a.join(" → ");if(t.type==="label")return a.map((x,i)=>(i+1)+" "+(x||"–")).join(", ");if(t.type==="zelle")return "Zellschicht: "+(a[0].trim()||"–")+" | Aufgabe: "+(a[1].trim()||"–");if(t.type==="stamm")return "Merkmale: "+(a[0].trim()||"–")+" | Tiergruppen: "+(a[1].trim()||"–");if(t.type==="match"||t.type==="sort"){const rs=t.type==="match"?t.pairs:t.items;return rs.map((r,i)=>r[0]+": "+(a[i]||"–")+(a[i]===r[1]?" ✓":" ✗ ("+r[1]+")")).join("; ")}return a};
  view(h("h2",null,"Testergebnis"),
    h("div",{class:"grade"},h("span",{class:"gn"},round.toFixed(1)),h("div",null,h("div",null,h("b",null,p.toFixed(1)+" von "+m+" Punkten")),h("div",{class:"small muted"},"genaue Note "+note.toFixed(2)+", gerundet auf halbe Noten"))),
    h("div",{class:"panel"},h("h3",null,"Nach Lernziel"),LZ.filter(l=>byLz[l.id]).map(l=>{const b=byLz[l.id];const pc=b.p/b.m;return h("div",{class:"lzr"},h("span",null,l.id+" "+l.t),h("span",{class:"mini"},h("i",{style:"width:"+Math.round(pc*100)+"%;background:"+(pc>=.8?"var(--ok)":pc>=.5?"var(--warn)":"var(--bad)")})),h("span",{class:"small"},b.p.toFixed(1)+"/"+b.m))})),
    h("h3",{style:"margin-top:22px"},"Alle Aufgaben mit Korrektur"),
    h("div",{class:"rev"},rows.map(([t,a,g,pt],i)=>h("div",{class:"rv "+(g.s>=1?"ok":g.s>0?"warn":"bad")},
      h("div",{class:"small muted"},(i+1)+". "+t.lz+(t.denk?", Denkaufgabe":"")+" – "+(Math.round(g.s*pt*10)/10)+"/"+pt+" P."),
      h("div",null,h("b",null,t.q)),h("div",{class:"small"},"Deine Antwort: "+ansText(t,a)),
      g.s<1&&g.sol?h("div",{class:"small"},"Richtig: "+g.sol):null,t.ex?h("div",{class:"small muted"},t.ex):null))),
    h("div",{class:"row",style:"margin-top:20px"},h("button",{class:"primary",onclick:testRun},"Neuer Test (andere Aufgaben)"),h("button",{onclick:home},"Zur Übersicht")));
}

/* ---------- Start ---------- */
function home(){
  document.onkeydown=null;
  const last=tests[tests.length-1];
  view(
    h("h1",null,h("span",{class:"hl"},APP.title)," üben"),
    h("p",{class:"muted",style:"margin-top:8px"},APP.sub),
    h("div",{class:"big"},
      h("button",{class:"bigb lead",onclick:mixRound},h("b",null,"Gemischte Übung"),h("span",null,"16 Aufgaben aus allen "+LZ.length+" Lernzielen, mit sofortiger Rückmeldung")),
      h("button",{class:"bigb",onclick:testIntro},h("b",null,"Prüfung mit Note"),h("span",null,last?"Letzte Note: "+last.note.toFixed(1):(APP.exam||"Wie die echte Prüfung: 9 Aufgaben, 32 Punkte, 40 Minuten")))),
    h("h2",{style:"margin-top:28px"},"Nach Lernziel üben"),
    h("p",{class:"small muted",style:"margin:4px 0 0"},"Tippe ein Lernziel an: Zuerst siehst du das Wichtigste mit Zeichnungen, dann übst du alle Aufgaben dazu."),
    SECTIONS.map(([sec,ids])=>[h("h3",{class:"sec"},sec),h("div",{class:"lzlist"},LZ.filter(l=>ids.includes(l.id)).map(l=>{const b=bank(l.id);const all=b.core.concat(b.extra);const done=all.filter(t=>ok[ck(t)]).length;const pc=Math.round(done/all.length*100);
      return h("button",{class:"lzb",onclick:()=>lzPage(l.id)},h("span",{class:"lid"},l.id),h("span",{class:"lt"},h("b",null,l.t),h("span",{class:"small muted"},l.d)),h("span",{class:"lp"},h("span",{class:"mini"},h("i",{style:"width:"+pc+"%"})),h("span",{class:"small muted"},pc+" %")))}))]),
    h("p",{class:"small muted",style:"margin-top:18px"},"Der Balken zeigt, wie viele Aufgaben des Lernziels du schon richtig gelöst hast. Dein Fortschritt bleibt in diesem Browser gespeichert."),
    (()=>{const rb=h("button",{class:"ghost small",onclick:()=>twoStep(rb,"Fortschritt zurücksetzen","Wirklich alles löschen? Nochmals tippen",()=>{["seen","tseen","ok","lz","tests","ts"].forEach(k=>{try{localStorage.removeItem(APP.prefix+k)}catch(e){}});seen={};tseen={};ok={};lzStat={};tests=[];ts={};home()})},"Fortschritt zurücksetzen");return rb})()
  );
}

