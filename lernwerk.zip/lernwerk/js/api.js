/* ===== Verbindung zum Server (Supabase) – oder Demo-Modus, wenn noch nichts eingerichtet ist ===== */
const CFG=window.LP_CONFIG||{};
const DEMO=!CFG.SUPABASE_URL||!CFG.SUPABASE_ANON_KEY||typeof supabase==="undefined";
const MAX_TEXT=CFG.MAX_TEXT_CHARS||40000;

/* Kleine Hilfen */
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function sha256(t){const b=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(t));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join("")}
const ls={get(k,d){try{return JSON.parse(localStorage.getItem(k))??d}catch(e){return d}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}},del(k){try{localStorage.removeItem(k)}catch(e){}}};
const uid=()=>(crypto.randomUUID?crypto.randomUUID():Date.now().toString(36)+Math.random().toString(36).slice(2));
class ApiError extends Error{constructor(msg,code){super(msg);this.code=code}}

/* ---------- Supabase ---------- */
function supabaseApi(){
  const sb=supabase.createClient(CFG.SUPABASE_URL,CFG.SUPABASE_ANON_KEY);
  const must=({data,error})=>{if(error)throw new ApiError(deMsg(error.message),error.code);return data};
  const me=async()=>{const {data}=await sb.auth.getUser();if(!data.user)throw new ApiError("Du bist nicht angemeldet.","auth");return data.user};
  return {
    mode:"server",
    async session(){const {data}=await sb.auth.getSession();return data.session?{id:data.session.user.id,email:data.session.user.email}:null},
    onAuth(fn){sb.auth.onAuthStateChange((ev)=>fn(ev))},
    async signUp(email,pw,name){const r=await sb.auth.signUp({email,password:pw,options:{data:{display_name:name},emailRedirectTo:location.origin+location.pathname}});must(r);return {needsConfirm:!r.data.session}},
    async signIn(email,pw){must(await sb.auth.signInWithPassword({email,password:pw}))},
    async signOut(){await sb.auth.signOut()},
    async resetPassword(email){must(await sb.auth.resetPasswordForEmail(email,{redirectTo:location.origin+location.pathname+"#neues-passwort"}))},
    async updatePassword(pw){must(await sb.auth.updateUser({password:pw}))},
    async getProfile(){const u=await me();const d=must(await sb.from("profiles").select("display_name,settings,game").eq("id",u.id).maybeSingle());return d||{display_name:"",settings:{},game:{}}},
    async saveProfile(p){const u=await me();must(await sb.from("profiles").update(p).eq("id",u.id))},
    async listSummaries(){return must(await sb.from("summaries").select("id,title,status,created_at,progress_pc").order("created_at",{ascending:false}))},
    async getSummary(id){return must(await sb.from("summaries").select("id,title,source_text,data,progress,status").eq("id",id).single())},
    async createSummary(title,text){const u=await me();return must(await sb.from("summaries").insert({user_id:u.id,title,source_text:text,status:"wird erstellt"}).select("id").single()).id},
    async updateSummary(id,p){must(await sb.from("summaries").update(p).eq("id",id))},
    async deleteSummary(id){must(await sb.from("summaries").delete().eq("id",id))},
    async callGenerate(body){const {data,error}=await sb.functions.invoke("generate",{body});
      if(error){let msg="Der Server konnte das Lernset nicht erstellen.";try{const j=await error.context.json();if(j&&j.error)msg=j.error}catch(e){}throw new ApiError(msg,"gen")}
      if(data&&data.error)throw new ApiError(data.error,"gen");return data},
    async deleteAccount(){const {data,error}=await sb.functions.invoke("konto-loeschen",{body:{}});if(error||(data&&data.error))throw new ApiError("Das Konto konnte nicht gelöscht werden. Versuche es später nochmals.","del");await sb.auth.signOut()}
  };
}
function deMsg(m){m=String(m||"");
  if(/Invalid login credentials/i.test(m))return "E-Mail oder Passwort ist falsch.";
  if(/Email not confirmed/i.test(m))return "Bitte bestätige zuerst deine E-Mail-Adresse (Link im Mail).";
  if(/already registered|already exists/i.test(m))return "Mit dieser E-Mail-Adresse gibt es schon ein Konto.";
  if(/Password should be/i.test(m))return "Das Passwort ist zu kurz (mindestens 8 Zeichen).";
  if(/rate limit/i.test(m))return "Zu viele Versuche. Warte kurz und versuche es nochmals.";
  if(/fetch|network/i.test(m))return "Keine Verbindung zum Server. Prüfe dein Internet.";
  return m}

/* ---------- Demo-Modus (alles nur in diesem Browser, ohne KI) ---------- */
function demoApi(){
  const U="lpdemo:users",SES="lpdemo:session";
  const cur=()=>{const id=ls.get(SES,null);if(!id)throw new ApiError("Du bist nicht angemeldet.","auth");return id};
  const sumKey=()=>"lpdemo:summaries:"+cur();
  let authFn=()=>{};
  return {
    mode:"demo",
    async session(){const id=ls.get(SES,null);if(!id)return null;const u=Object.values(ls.get(U,{})).find(x=>x.id===id);return u?{id,email:u.email}:null},
    onAuth(fn){authFn=fn},
    async signUp(email,pw,name){const us=ls.get(U,{});const k=email.toLowerCase();if(us[k])throw new ApiError("Mit dieser E-Mail-Adresse gibt es schon ein Konto.");
      const id=uid();us[k]={id,email:k,pw:await sha256(k+":"+pw)};ls.set(U,us);ls.set("lpdemo:profile:"+id,{display_name:name,settings:{},game:{}});ls.set(SES,id);return {needsConfirm:false}},
    async signIn(email,pw){const u=ls.get(U,{})[email.toLowerCase()];if(!u||u.pw!==await sha256(email.toLowerCase()+":"+pw))throw new ApiError("E-Mail oder Passwort ist falsch.");ls.set(SES,u.id)},
    async signOut(){ls.del(SES)},
    async resetPassword(){throw new ApiError("Im Demo-Modus gibt es keine E-Mails. Erstelle einfach ein neues Konto.")},
    async updatePassword(pw){const id=cur();const us=ls.get(U,{});const k=Object.keys(us).find(k=>us[k].id===id);us[k].pw=await sha256(k+":"+pw);ls.set(U,us)},
    async getProfile(){return ls.get("lpdemo:profile:"+cur(),{display_name:"",settings:{},game:{}})},
    async saveProfile(p){const k="lpdemo:profile:"+cur();ls.set(k,Object.assign(ls.get(k,{}),p))},
    async listSummaries(){return ls.get(sumKey(),[]).map(s=>({id:s.id,title:s.title,status:s.status,created_at:s.created_at,progress_pc:s.progress_pc||0}))},
    async getSummary(id){const s=ls.get(sumKey(),[]).find(x=>x.id===id);if(!s)throw new ApiError("Nicht gefunden.");return s},
    async createSummary(title,text){const l=ls.get(sumKey(),[]);const id=uid();l.unshift({id,title,source_text:text,data:null,progress:{},status:"wird erstellt",created_at:new Date().toISOString()});ls.set(sumKey(),l);return id},
    async updateSummary(id,p){const l=ls.get(sumKey(),[]);const s=l.find(x=>x.id===id);if(s)Object.assign(s,p);ls.set(sumKey(),l)},
    async deleteSummary(id){ls.set(sumKey(),ls.get(sumKey(),[]).filter(x=>x.id!==id))},
    async callGenerate(){throw new ApiError("Im Demo-Modus gibt es keine KI.","demo")},
    async deleteAccount(){const id=cur();const us=ls.get(U,{});Object.keys(us).forEach(k=>{if(us[k].id===id)delete us[k]});ls.set(U,us);ls.del("lpdemo:profile:"+id);ls.del("lpdemo:summaries:"+id);ls.del(SES)}
  };
}
const API=DEMO?demoApi():supabaseApi();

/* ---------- Lernset erstellen: KI in mehreren kurzen Schritten (sonst einfacher Generator) ---------- */
async function generateSet(id,title,text,settings,onStep){
  if(API.mode==="demo"||CFG.KI===false){onStep("Ich lese deine Zusammenfassung …",.3);await sleep(500);onStep("Ich erstelle die Aufgaben …",.7);await sleep(400);return heuristicSet(title,text)}
  onStep("Ich lese deine Zusammenfassung und finde die Lernziele …",.08);
  const plan=await API.callGenerate({summary_id:id,step:"plan",niveau:settings.niveau});
  const lz=(plan.lernziele||[]).map((l,i)=>Object.assign({},l,{id:"L"+(i+1)}));
  if(!lz.length)throw new ApiError("In dieser Zusammenfassung habe ich keine Lernziele gefunden.");
  const chunks=[];for(let i=0;i<lz.length;i+=2)chunks.push(lz.slice(i,i+2));
  let aufgaben=[];
  for(let k=0;k<chunks.length;k++){onStep("Ich erstelle Aufgaben zu «"+chunks[k].map(l=>l.titel).join("», «")+"» …",.15+.8*k/chunks.length);
    let r=null;for(let tr=0;tr<2&&!r;tr++){try{r=await API.callGenerate({summary_id:id,step:"aufgaben",niveau:settings.niveau,lernziele:chunks[k].map(l=>({id:l.id,titel:l.titel,beschreibung:l.beschreibung}))})}catch(e){if(tr===1)throw e;await sleep(1500)}}
    aufgaben=aufgaben.concat(r.aufgaben||[])}
  onStep("Fertig! Ich prüfe noch alles …",.98);
  return {titel:plan.titel||title,lernziele:lz,aufgaben,begriffe:plan.begriffe||[],ereignisse:plan.ereignisse||[],raetsel:plan.raetsel||[],quelle:"ki"};
}
