/* ===== Lernset-Daten: prüfen, aufbereiten und in die Lern-Engine laden ===== */
const APPCFG={title:"",sub:"",prefix:"lp:none:",exam:""};
let LZ=[],GEN={},INFO={},SECTIONS=[],DATA=null,BEGRIFFE=[];
const R=a=>a[Math.floor(Math.random()*a.length)];
const SH=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
const PICK=(a,n)=>SH(a).slice(0,n);
const KEY=a=>a.map(String).sort().join("|");
function mc(id,q,right,wrong,o={}){const opts=SH([...right.map(t=>[t,1]),...wrong.map(t=>[t,0])]);
  return Object.assign({id,type:"mc",q,opts:opts.map(x=>x[0]),ok:opts.map((x,i)=>x[1]?i:-1).filter(i=>i>=0),multi:right.length>1},o)}

/* ---------- Prüfen (die KI kann Fehler machen – alles Unbrauchbare fliegt raus) ---------- */
const S=(x,max=400)=>typeof x==="string"?x.replace(/[\u0000-\u0008\u000B-\u001F]/g,"").trim().slice(0,max):(typeof x==="number"?String(x):"");
const SA=(a,max,min=0,len=200)=>Array.isArray(a)?a.map(x=>S(x,len)).filter(Boolean).slice(0,max):[];
function cleanTask(a){
  if(!a||typeof a!=="object")return null;const type=S(a.type,20),q=S(a.q,600);if(!q)return null;
  const base={type,q,lz:S(a.lz,10),extra:!!a.extra,denk:!!a.denk};const ex=S(a.ex,400);if(ex)base.ex=ex;
  switch(type){
    case "text":{const acc=SA(a.acc,8,1,120);return acc.length?Object.assign(base,{acc}):null}
    case "textn":{const groups=(Array.isArray(a.groups)?a.groups:[]).map(g=>SA(g,10,1,60).map(k=>k.toLowerCase())).filter(g=>g.length).slice(0,10);
      if(!groups.length)return null;const show=SA(a.show,10,0,300);const n=Math.max(1,Math.min(groups.length,parseInt(a.n)||groups.length));
      return Object.assign(base,{kw:true,groups,n,show:show.length?show:groups.map(g=>g[0])})}
    case "mc":{const opts=SA(a.opts,6,2,200);const ok=(Array.isArray(a.ok)?a.ok:[]).map(Number).filter(i=>Number.isInteger(i)&&i>=0&&i<opts.length);
      if(opts.length<2||!ok.length)return null;return Object.assign(base,{opts,ok:[...new Set(ok)],multi:new Set(ok).size>1})}
    case "tf":{if(typeof a.val!=="boolean")return null;return Object.assign(base,{val:a.val})}
    case "match":{const pairs=(Array.isArray(a.pairs)?a.pairs:[]).map(p=>Array.isArray(p)?[S(p[0],120),S(p[1],200)]:null).filter(p=>p&&p[0]&&p[1]).slice(0,6);
      if(pairs.length<3||new Set(pairs.map(p=>p[1])).size<pairs.length)return null;base.id="m-"+KEY(pairs.map(p=>p[0]));return Object.assign(base,{pairs})}
    case "sort":{const cats=SA(a.cats,4,2,60);const items=(Array.isArray(a.items)?a.items:[]).map(p=>Array.isArray(p)?[S(p[0],160),S(p[1],60)]:null).filter(p=>p&&p[0]&&cats.includes(p[1])).slice(0,8);
      if(cats.length<2||items.length<3)return null;base.id="s-"+KEY(items.map(p=>p[0]));return Object.assign(base,{cats,items})}
    case "order":{const items=SA(a.items,7,3,160);if(items.length<3||new Set(items).size<items.length)return null;base.id="o-"+KEY(items);return Object.assign(base,{items})}
    case "cloze":{const parts=(Array.isArray(a.parts)?a.parts:[]).map(p=>typeof p==="string"?S(p,600):(p&&typeof p==="object"?{acc:SA(p.acc,6,1,60),show:S(p.show,60)}:null)).filter(p=>p!==null&&p!=="");
      const gaps=parts.filter(p=>typeof p!=="string");if(!gaps.length||gaps.some(g=>!g.acc.length))return null;gaps.forEach(g=>{if(!g.show)g.show=g.acc[0]});return Object.assign(base,{parts})}
    case "rows":{const rows=(Array.isArray(a.rows)?a.rows:[]).map(r=>Array.isArray(r)?[S(r[0],200),SA(r[1],6,1,80),S(r[2],120)]:null).filter(r=>r&&r[0]&&r[1].length).slice(0,6);
      if(!rows.length)return null;rows.forEach(r=>{if(!r[2])r[2]=r[1][0]});return Object.assign(base,{rows})}
  }
  return null;
}
function cleanSet(d){
  d=d&&typeof d==="object"?d:{};
  const lernziele=(Array.isArray(d.lernziele)?d.lernziele:[]).map((l,i)=>({id:"L"+(i+1),alt:S(l&&l.id,10),titel:S(l&&l.titel,140)||"Lernziel "+(i+1),beschreibung:S(l&&l.beschreibung,240),
    info:SA(l&&l.info,20,0,400),tabelle:(l&&l.tabelle&&Array.isArray(l.tabelle.kopf)&&Array.isArray(l.tabelle.zeilen))?{kopf:SA(l.tabelle.kopf,5,0,80),zeilen:l.tabelle.zeilen.slice(0,15).map(z=>SA(z,5,0,300))}:null})).slice(0,25);
  const idMap={};lernziele.forEach(l=>{if(l.alt)idMap[l.alt]=l.id;idMap[l.id]=idMap[l.id]||l.id});
  const aufgaben=(Array.isArray(d.aufgaben)?d.aufgaben:[]).map(cleanTask).filter(Boolean).map(t=>{t.lz=idMap[t.lz]||(lernziele[0]&&lernziele[0].id)||"L1";return t}).slice(0,600);
  const begriffe=(Array.isArray(d.begriffe)?d.begriffe:[]).map(b=>({begriff:S(b&&b.begriff,80),erklaerung:S(b&&b.erklaerung,400),stichwoerter:(Array.isArray(b&&b.stichwoerter)?b.stichwoerter:[]).map(g=>SA(g,8,1,50).map(k=>k.toLowerCase())).filter(g=>g.length).slice(0,4)}))
    .filter(b=>b.begriff&&b.erklaerung).slice(0,80);
  const ereignisse=(Array.isArray(d.ereignisse)?d.ereignisse:[]).map(e=>({jahr:Number(e&&e.jahr),text:S(e&&e.text,160)})).filter(e=>Number.isFinite(e.jahr)&&e.text).slice(0,60);
  const raetsel=(Array.isArray(d.raetsel)?d.raetsel:[]).map(r=>({loesung:S(r&&r.loesung,60),alternativen:SA(r&&r.alternativen,5,0,60),hinweise:SA(r&&r.hinweise,3,0,240)})).filter(r=>r.loesung&&r.hinweise.length===3).slice(0,40);
  return {titel:S(d.titel,140),lernziele,aufgaben,begriffe,ereignisse,raetsel,quelle:S(d.quelle,20)||"ki"};
}

/* ---------- In die Engine laden ---------- */
function begriffTasks(){const core=[],extra=[];
  BEGRIFFE.forEach((b,i)=>{const groups=b.stichwoerter.length?b.stichwoerter:[[norm(b.erklaerung).split(" ").filter(w=>w.length>5)[0]||norm(b.begriff)]];
    core.push({type:"textn",kw:true,n:groups.length,q:"Erkläre den Begriff «"+b.begriff+"».",groups,show:[b.erklaerung]});
    extra.push({type:"text",q:"Welcher Begriff ist gemeint? «"+b.erklaerung+"»",acc:[b.begriff]})});
  const sh=SH(BEGRIFFE);for(let k=0;k+3<=sh.length&&k<16;k+=4){const pr=sh.slice(k,k+4);if(pr.length>=3)extra.push({id:"bm-"+KEY(pr.map(b=>b.begriff)),type:"match",q:"Welche Erklärung passt zum Begriff?",pairs:pr.map(b=>[b.begriff,b.erklaerung.length>110?b.erklaerung.slice(0,107)+"…":b.erklaerung])})}
  return {core,extra}}
function applyData(raw){
  DATA=cleanSet(raw);BEGRIFFE=DATA.begriffe;
  LZ=DATA.lernziele.map(l=>({id:l.id,t:l.titel,d:l.beschreibung}));INFO={};GEN={};
  DATA.lernziele.forEach(l=>{INFO[l.id]={f:l.info.length?l.info:["(Keine Infos – übe direkt mit den Aufgaben.)"],table:l.tabelle&&l.tabelle.kopf.length?{head:l.tabelle.kopf,rows:l.tabelle.zeilen}:null};
    const mine=DATA.aufgaben.filter(a=>a.lz===l.id);
    GEN[l.id]=()=>{const c=mine.map(t=>JSON.parse(JSON.stringify(t)));return {core:c.filter(t=>!t.extra),extra:c.filter(t=>t.extra)}}});
  if(BEGRIFFE.length>=2){LZ.unshift({id:"L0",t:"Wichtige Begriffe",d:BEGRIFFE.length+" Begriffe erklären können"});INFO.L0={f:BEGRIFFE.map(b=>b.begriff+": "+b.erklaerung)};GEN.L0=begriffTasks}
  LZ=LZ.filter(l=>{const b=GEN[l.id]();return b.core.length+b.extra.length>0});
  LZ.forEach(l=>{const b=GEN[l.id]();if(!b.core.length&&b.extra.length){const g=GEN[l.id];GEN[l.id]=()=>{const x=g();return {core:x.extra,extra:[]}}}});
  SECTIONS=[["Lernziele",LZ.map(l=>l.id)]];
}

/* ---------- Automatische Probeprüfung aus dem Lernset ---------- */
const PTS_OF=t=>t.type==="textn"?Math.min(3,Math.max(1,t.n)):["match","sort","order","cloze","rows"].includes(t.type)?2:t.denk?2:1;
function autoExam(){
  const A=[];const AB=i=>String.fromCharCode(97+i)+") ";
  if(BEGRIFFE.length>=4){const nb=Math.min(6,4+Math.floor(Math.random()*3));
    A.push({t:"Begriffe",parts:PICK(BEGRIFFE,nb).map((b,i)=>{const groups=b.stichwoerter.length?b.stichwoerter:[[norm(b.begriff)]];return {q:AB(i)+"Erkläre den Begriff «"+b.begriff+"».",pts:1,t:{type:"textn",kw:true,n:groups.length,groups,show:[b.erklaerung]}}})})}
  const lzs=LZ.filter(l=>l.id!=="L0");const pool=SH(lzs).slice(0,Math.min(7,lzs.length));
  pool.forEach(l=>{const b=GEN[l.id]();const c=SH(b.core.filter(t=>!t.denk)).slice(0,2);if(!c.length)return;
    A.push({t:l.t,parts:c.map((t,i)=>({q:(c.length>1?AB(i):"")+t.q,pts:PTS_OF(t),t}))})});
  const denk=SH(lzs.flatMap(l=>GEN[l.id]().core.concat(GEN[l.id]().extra).filter(t=>t.denk))).slice(0,2);
  if(denk.length)A.push({t:"Denkaufgaben",parts:denk.map((t,i)=>({q:(denk.length>1?AB(i):"")+t.q,pts:3,t}))});
  return {kind:"Probeprüfung",A};
}
